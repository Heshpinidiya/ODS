import React, { useState, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { CustomerRFQForm } from './components/CustomerRFQForm';
import { AdminRFQDashboard } from './components/AdminRFQDashboard';
import { GoogleSheetsIntegration } from './components/GoogleSheetsIntegrationModal';
import { SettingsComponent } from './components/SettingsModal';
import { RFQDetailModal } from './components/RFQDetailModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { CustomerTrackModal } from './components/CustomerTrackModal';
import { PrintQuotationDocument } from './components/PrintQuotationDocument';
import { PromoPopupAdModal } from './components/PromoPopupAdModal';
import { RFQRequest, RFQStatus, OwnerSettings, Language, QuotationPricingDetails } from './types';

const INITIAL_SETTINGS: OwnerSettings = {
  businessName: 'Office Depot Quotation Portal',
  tagline: 'REQUEST. QUOTE. DELIVER.',
  companyRegistrationNo: 'PV-90481',
  vatTinNumber: '104829104-7000',
  ownerName: 'Procurement Director',
  whatsappNumber: '94771234567',
  email: 'quotes@officedepot.lk',
  city: 'Colombo, Sri Lanka',
  address: 'No. 88, Commercial Avenue, Colombo 03',
  adminPasscode: 'admin123',
  googleSheetsWebhookUrl: '',
  responsePromiseHours: '2 - 4',
  currency: 'LKR',

  // Custom Bank Remittance Details
  bankName: 'Commercial Bank of Ceylon PLC',
  bankBranch: 'Colombo Corporate Branch',
  bankAccountName: 'Office Depot Lanka (Pvt) Ltd',
  bankAccountNumber: '1000 4829 1002',
  bankSwiftCode: 'CCEYLKLX',

  // Email Notification for Incoming RFQs
  adminNotificationEmail: 'heshpinidiya@gmail.com',
  enableEmailAlerts: true,

  // Promotional Pop-up Announcement Ad on First Visit
  popupAdEnabled: true,
  popupAdTitle: '🎉 Corporate Bulk Supplies Special Offer',
  popupAdSubtitle: 'Get up to 20% discount on Office Stationery, Paper & Toners this month!',
  popupAdAspectRatio: '1:1',
  popupAdMediaType: 'image',
  popupAdMediaUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80',
  popupAdCtaText: 'Request Quotation Now',
  popupAdCtaLink: '#rfq-form',
};

export default function App() {
  const [language, setLanguage] = useState<Language>('si');
  const [currentTab, setCurrentTab] = useState<'customer' | 'admin' | 'sheets' | 'settings'>('customer');
  const [rfqs, setRfqs] = useState<RFQRequest[]>([]);
  const [ownerSettings, setOwnerSettings] = useState<OwnerSettings>(INITIAL_SETTINGS);

  // Admin authentication state
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return typeof window !== 'undefined' ? !!localStorage.getItem('od_admin_auth') : false;
  });
  const [showAdminLoginModal, setShowAdminLoginModal] = useState<boolean>(false);
  const [showTrackModal, setShowTrackModal] = useState<boolean>(false);

  // Detailed Quoting Modal for Admin
  const [activeRfqForPricing, setActiveRfqForPricing] = useState<RFQRequest | null>(null);
  // Dedicated Official Print PDF Document View
  const [printRfq, setPrintRfq] = useState<RFQRequest | null>(null);

  // Promotional Pop-up Announcement Ad on First Visit
  const [showPromoPopup, setShowPromoPopup] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const dismissed = sessionStorage.getItem('od_popup_dismissed');
      if (!dismissed) {
        const timer = setTimeout(() => {
          setShowPromoPopup(true);
        }, 800);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const sRes = await fetch('/api/settings');
        if (sRes.ok) {
          const sData = await sRes.json();
          if (sData.settings) {
            setOwnerSettings((prev) => ({ ...prev, ...sData.settings }));
          }
        }

        const rRes = await fetch('/api/rfq');
        if (rRes.ok) {
          const rData = await rRes.json();
          if (Array.isArray(rData.rfqs)) {
            setRfqs(rData.rfqs);
          }
        }
      } catch (err) {
        console.warn('API error, using local fallback:', err);
        const local = localStorage.getItem('app_rfq_requests');
        if (local) {
          try {
            setRfqs(JSON.parse(local));
          } catch (e) {
            // ignore
          }
        }
      }
    };

    fetchData();
  }, []);

  // Sync to local storage
  useEffect(() => {
    if (rfqs.length > 0) {
      localStorage.setItem('app_rfq_requests', JSON.stringify(rfqs));
    }
  }, [rfqs]);

  const handleRequestSubmitted = (newRfq: RFQRequest) => {
    setRfqs((prev) => [newRfq, ...prev]);
  };

  // Admin updates quoted prices for an RFQ
  const handleUpdateQuotePricing = async (
    id: string,
    items: RFQRequest['items'],
    pricing: QuotationPricingDetails,
    ownerNotes: string,
    status: RFQStatus
  ) => {
    setRfqs((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              items,
              pricing,
              ourQuotedTotal: pricing.grandTotal,
              ownerNotes,
              status,
            }
          : r
      )
    );

    if (activeRfqForPricing && activeRfqForPricing.id === id) {
      setActiveRfqForPricing((prev) =>
        prev
          ? {
              ...prev,
              items,
              pricing,
              ourQuotedTotal: pricing.grandTotal,
              ownerNotes,
              status,
            }
          : null
      );
    }

    try {
      await fetch(`/api/rfq/${id}/quote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items, pricing, ownerNotes, status }),
      });
    } catch (err) {
      console.error('Error saving quote pricing on server:', err);
    }
  };

  const handleUpdateStatus = async (id: string, status: RFQStatus) => {
    setRfqs((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
    try {
      await fetch(`/api/rfq/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    } catch (err) {
      console.error('Error updating status on server:', err);
    }
  };

  const handleDeleteRFQ = async (id: string) => {
    setRfqs((prev) => prev.filter((r) => r.id !== id));
    if (activeRfqForPricing && activeRfqForPricing.id === id) {
      setActiveRfqForPricing(null);
    }

    try {
      await fetch(`/api/rfq/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.error('Error deleting RFQ on server:', err);
    }
  };

  const handleSaveSettings = async (newSettings: OwnerSettings) => {
    setOwnerSettings(newSettings);
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
    } catch (err) {
      console.error('Error saving settings on server:', err);
    }
  };

  const handleSaveWebhookUrl = (url: string) => {
    handleSaveSettings({ ...ownerSettings, googleSheetsWebhookUrl: url });
  };

  const handleRefresh = async () => {
    try {
      const res = await fetch('/api/rfq');
      if (res.ok) {
        const data = await res.json();
        if (data.rfqs) setRfqs(data.rfqs);
      }
    } catch (err) {
      console.error('Refresh error:', err);
    }
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('od_admin_auth');
    setIsAdminAuthenticated(false);
    setCurrentTab('customer');
  };

  const isSi = language === 'si';

  return (
    <div className="min-h-screen bg-neutral-900 text-neutral-100 flex flex-col font-sans antialiased selection:bg-[#00A6A6] selection:text-neutral-950">
      {/* Top Bar Navigation */}
      <TopBar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        language={language}
        setLanguage={setLanguage}
        receivedCount={rfqs.length}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenAdminLogin={() => setShowAdminLoginModal(true)}
        onAdminLogout={handleAdminLogout}
        onOpenTrackModal={() => setShowTrackModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'customer' && (
          <CustomerRFQForm
            language={language}
            ownerSettings={ownerSettings}
            onRequestSubmitted={handleRequestSubmitted}
            onOpenTrackModal={() => setShowTrackModal(true)}
            onOpenAdminLogin={() => {
              if (isAdminAuthenticated) {
                setCurrentTab('admin');
              } else {
                setShowAdminLoginModal(true);
              }
            }}
          />
        )}

        {currentTab === 'admin' && (
          isAdminAuthenticated ? (
            <AdminRFQDashboard
              rfqs={rfqs}
              language={language}
              ownerSettings={ownerSettings}
              onViewRFQ={(r) => setActiveRfqForPricing(r)}
              onOpenPrintView={(r) => setPrintRfq(r)}
              onUpdateStatus={handleUpdateStatus}
              onDeleteRFQ={handleDeleteRFQ}
              onRefresh={handleRefresh}
              onOpenCustomerForm={() => setCurrentTab('customer')}
              onOpenSheetsGuide={() => setCurrentTab('sheets')}
              onAdminLogout={handleAdminLogout}
            />
          ) : (
            <div className="max-w-md mx-auto text-center py-16 px-4 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#00A6A6]/20 border border-[#00A6A6] text-[#00A6A6] flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold">🔒</span>
              </div>
              <h2 className="text-xl font-bold text-white">
                {isSi ? 'පරිපාලක පිවිසුම අවශ්‍යයි' : 'Admin Login Required'}
              </h2>
              <p className="text-xs text-neutral-400">
                {isSi
                  ? 'ලැබුණු මිල කැඳවීම් සහ පාරිභෝගික තොරතුරු බැලීමට කරුණාකර මුරපදය ඇතුළත් කර Login වන්න.'
                  : 'Please log in with your administrator passcode to access quotation requests.'}
              </p>
              <button
                type="button"
                onClick={() => setShowAdminLoginModal(true)}
                className="px-6 py-2.5 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl transition-all shadow-md cursor-pointer"
              >
                {isSi ? 'Admin Login වන්න' : 'Login to Admin Panel'}
              </button>
            </div>
          )
        )}

        {currentTab === 'sheets' && (
          isAdminAuthenticated ? (
            <GoogleSheetsIntegration
              language={language}
              rfqs={rfqs}
              ownerSettings={ownerSettings}
              onSaveWebhookUrl={handleSaveWebhookUrl}
            />
          ) : (
            <div className="max-w-md mx-auto text-center py-16 px-4 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold">📊</span>
              </div>
              <h2 className="text-xl font-bold text-white">
                {isSi ? 'Google Sheets Admin සඳහා පිවිසෙන්න' : 'Admin Authentication Required'}
              </h2>
              <button
                type="button"
                onClick={() => setShowAdminLoginModal(true)}
                className="px-6 py-2.5 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#15bfbf] rounded-xl transition-all shadow-md cursor-pointer"
              >
                {isSi ? 'Admin Login වන්න' : 'Login to View Google Sheets'}
              </button>
            </div>
          )
        )}

        {currentTab === 'settings' && (
          isAdminAuthenticated ? (
            <SettingsComponent
              settings={ownerSettings}
              language={language}
              onSaveSettings={handleSaveSettings}
            />
          ) : (
            <div className="max-w-md mx-auto text-center py-16 px-4 space-y-4">
              <h2 className="text-xl font-bold text-white">
                {isSi ? 'සැකසුම් සඳහා Admin Login වන්න' : 'Admin Login Required'}
              </h2>
              <button
                type="button"
                onClick={() => setShowAdminLoginModal(true)}
                className="px-6 py-2.5 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl cursor-pointer"
              >
                {isSi ? 'Admin Login වන්න' : 'Login to Admin'}
              </button>
            </div>
          )
        )}
      </main>

      {/* Admin Quoting & Proposal Generator Modal */}
      {activeRfqForPricing && (
        <RFQDetailModal
          rfq={activeRfqForPricing}
          language={language}
          ownerSettings={ownerSettings}
          onClose={() => setActiveRfqForPricing(null)}
          onUpdateQuotePricing={handleUpdateQuotePricing}
          onOpenPrintView={(r) => setPrintRfq(r)}
        />
      )}

      {/* Official Office Depot Letterhead Printable Quotation View */}
      {printRfq && (
        <PrintQuotationDocument
          rfq={printRfq}
          ownerSettings={ownerSettings}
          language={language}
          onClose={() => setPrintRfq(null)}
        />
      )}

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={showAdminLoginModal}
        language={language}
        onClose={() => setShowAdminLoginModal(false)}
        onLoginSuccess={() => {
          setIsAdminAuthenticated(true);
          setShowAdminLoginModal(false);
          setCurrentTab('admin');
        }}
      />

      {/* Customer Quotation Status Tracker Modal */}
      <CustomerTrackModal
        isOpen={showTrackModal}
        language={language}
        ownerSettings={ownerSettings}
        onClose={() => setShowTrackModal(false)}
        onOpenPrintView={(r) => setPrintRfq(r)}
      />

      {/* Promotional Pop-up Announcement Ad Modal (1:1 or 9:16, Image/Video) */}
      {showPromoPopup && ownerSettings.popupAdEnabled && (
        <PromoPopupAdModal
          settings={ownerSettings}
          language={language}
          onClose={() => setShowPromoPopup(false)}
          onActionClick={() => {
            setShowPromoPopup(false);
            setCurrentTab('customer');
            window.scrollTo({ top: 350, behavior: 'smooth' });
          }}
        />
      )}

      {/* Premium Dark Corporate Footer */}
      <footer className="border-t border-neutral-800 bg-[#0B1F33] py-6 mt-12 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div>
            <span className="font-bold text-white tracking-wider">
              {ownerSettings.businessName}
            </span>{' '}
            — <span className="text-[#FF7A00] font-semibold">{ownerSettings.tagline}</span>
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <button
              type="button"
              onClick={() => setCurrentTab('customer')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              {isSi ? 'මිල කැඳවුම' : 'Request Quote'}
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => setShowTrackModal(true)}
              className="hover:text-[#00A6A6] transition-colors cursor-pointer"
            >
              {isSi ? 'Track කරන්න' : 'Track Quote'}
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => {
                if (isAdminAuthenticated) {
                  setCurrentTab('admin');
                } else {
                  setShowAdminLoginModal(true);
                }
              }}
              className="hover:text-[#FF7A00] transition-colors cursor-pointer"
            >
              Admin Portal
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
