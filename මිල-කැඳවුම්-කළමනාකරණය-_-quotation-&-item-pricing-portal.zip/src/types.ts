export interface UploadedAttachment {
  id: string;
  name: string;
  size: number;
  type: 'excel' | 'pdf' | 'image' | 'doc' | 'other';
  dataUrl: string; // base64 representation
}

export interface RFQItem {
  id: string;
  name: string;
  specs?: string;
  quantity: number;
  unit: string;
  targetBudget?: number;
  remarks?: string;
  // Quoted pricing fields set by Admin
  quotedUnitPrice?: number;
  quotedTotal?: number;
  available?: boolean;
}

export type UrgencyLevel = 'urgent' | 'normal' | 'flexible';

export interface CustomerInfo {
  name: string;
  company?: string;
  phone: string;
  email?: string;
  deliveryLocation: string;
  urgency: UrgencyLevel;
  requiredDate?: string;
  notes?: string;
}

export type RFQStatus = 'new' | 'quoted' | 'contacted' | 'completed' | 'cancelled';

export interface QuotationPricingDetails {
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  taxPercent: number;
  taxAmount: number;
  deliveryFee: number;
  grandTotal: number;
  validDays: number;
  deliveryEstimate: string;
  paymentTerms: string;
  notes: string;
  quotedAt: string;
}

export interface RFQRequest {
  id: string;
  referenceNumber: string;
  createdAt: string;
  status: RFQStatus;
  customer: CustomerInfo;
  items: RFQItem[];
  attachments?: UploadedAttachment[];
  pricing?: QuotationPricingDetails;
  ourQuotedTotal?: number;
  ownerNotes?: string;
}

export interface OwnerSettings {
  businessName: string;
  tagline: string;
  companyRegistrationNo?: string; // e.g. PV-90481
  vatTinNumber?: string; // e.g. 104829104-7000
  ownerName: string;
  whatsappNumber: string;
  email: string;
  city: string;
  address: string;
  adminPasscode: string; // PIN to restrict admin access
  googleSheetsWebhookUrl?: string;
  responsePromiseHours: string;
  currency: string;

  // Manual Bank Remittance Details
  bankName?: string;
  bankBranch?: string;
  bankAccountName?: string;
  bankAccountNumber?: string;
  bankSwiftCode?: string;

  // Quotation Copy Email Notification
  adminNotificationEmail?: string;
  enableEmailAlerts?: boolean;

  // Promotional Pop-up Announcement / Ad on Visit
  popupAdEnabled?: boolean;
  popupAdTitle?: string;
  popupAdSubtitle?: string;
  popupAdAspectRatio?: '1:1' | '9:16';
  popupAdMediaType?: 'image' | 'video';
  popupAdMediaUrl?: string;
  popupAdCtaText?: string;
  popupAdCtaLink?: string;

  // Custom Commercial Terms and Conditions
  customTermsAndConditions?: string;
}

export type Language = 'si' | 'en';
