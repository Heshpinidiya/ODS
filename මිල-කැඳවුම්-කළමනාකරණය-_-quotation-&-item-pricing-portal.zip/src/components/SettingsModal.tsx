import React, { useState } from 'react';
import {
  Settings,
  Save,
  Check,
  Building,
  Phone,
  Mail,
  FileSpreadsheet,
  Lock,
  Tag,
  MapPin,
  CreditCard,
  Bell,
  Sparkles,
  Upload,
  Eye,
  FileText
} from 'lucide-react';
import { OwnerSettings, Language } from '../types';

interface SettingsComponentProps {
  settings: OwnerSettings;
  language: Language;
  onSaveSettings: (settings: OwnerSettings) => void;
}

export const SettingsComponent: React.FC<SettingsComponentProps> = ({
  settings,
  language,
  onSaveSettings,
}) => {
  const isSi = language === 'si';

  const [formData, setFormData] = useState<OwnerSettings>({
    ...settings,
    companyRegistrationNo: settings.companyRegistrationNo || 'PV-90481',
    vatTinNumber: settings.vatTinNumber || '104829104-7000',
    bankName: settings.bankName || 'Commercial Bank of Ceylon PLC',
    bankBranch: settings.bankBranch || 'Colombo Corporate Branch',
    bankAccountName: settings.bankAccountName || 'Office Depot Lanka (Pvt) Ltd',
    bankAccountNumber: settings.bankAccountNumber || '1000 4829 1002',
    bankSwiftCode: settings.bankSwiftCode || 'CCEYLKLX',
    adminNotificationEmail: settings.adminNotificationEmail || settings.email || 'heshpinidiya@gmail.com',
    enableEmailAlerts: settings.enableEmailAlerts ?? true,
    popupAdEnabled: settings.popupAdEnabled ?? true,
    popupAdTitle: settings.popupAdTitle || '🎉 Corporate Bulk Supplies Special Offer',
    popupAdSubtitle: settings.popupAdSubtitle || 'Get up to 20% discount on Office Stationery, Paper & Toners this month!',
    popupAdAspectRatio: settings.popupAdAspectRatio || '1:1',
    popupAdMediaType: settings.popupAdMediaType || 'image',
    popupAdMediaUrl: settings.popupAdMediaUrl || 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80',
    popupAdCtaText: settings.popupAdCtaText || 'Request Quotation Now',
    popupAdCtaLink: settings.popupAdCtaLink || '#rfq-form',
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'business' | 'bank' | 'notifications' | 'popup'>('business');
  const [showAdPreview, setShowAdPreview] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    const reader = new FileReader();
    reader.onload = () => {
      setFormData((prev) => ({
        ...prev,
        popupAdMediaUrl: reader.result as string,
        popupAdMediaType: isVideo ? 'video' : 'image',
      }));
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-6 sm:p-8 shadow-xl">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#00A6A6]/20 border border-[#00A6A6] text-[#00A6A6] flex items-center justify-center shrink-0">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {isSi ? 'පද්ධති සහ ව්‍යාපාරික සැකසුම් (Portal Settings)' : 'System & Business Settings'}
              </h1>
              <p className="text-xs text-neutral-300 mt-0.5">
                {isSi
                  ? 'බිස්නස් තොරතුරු, බැංකු විස්තර, ඊමේල් දැනුම්දීම් සහ Pop-up දැන්වීම් මෙතැනින් කළමනාකරණය කරන්න.'
                  : 'Configure business profile, remittance bank details, incoming quote email alerts, and pop-up ads.'}
              </p>
            </div>
          </div>

          {savedSuccess && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold shrink-0">
              <Check className="w-4 h-4" />
              <span>{isSi ? 'සාර්ථකව සුරැකිණි!' : 'Saved successfully!'}</span>
            </span>
          )}
        </div>

        {/* Inner Sub-navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 pt-6 border-b border-neutral-800 pb-4">
          <button
            type="button"
            onClick={() => setActiveTab('business')}
            className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'business'
                ? 'bg-[#00A6A6] text-neutral-950 shadow-md'
                : 'bg-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>{isSi ? '1. ව්‍යාපාරික තොරතුරු' : '1. Business Profile'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('bank')}
            className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'bank'
                ? 'bg-[#00A6A6] text-neutral-950 shadow-md'
                : 'bg-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>{isSi ? '2. බැංකු විස්තර (Bank Remittance)' : '2. Bank Details'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('notifications')}
            className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-[#00A6A6] text-neutral-950 shadow-md'
                : 'bg-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>{isSi ? '3. Email සහ Webhooks' : '3. Email & Alerts'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('popup')}
            className={`px-3.5 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'popup'
                ? 'bg-[#FF7A00] text-neutral-950 shadow-md'
                : 'bg-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{isSi ? '4. Pop-up දැන්වීම් (1:1 / 9:16)' : '4. Pop-up Ads'}</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          {/* TAB 1: BUSINESS PROFILE */}
          {activeTab === 'business' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <h3 className="text-xs font-bold text-[#00A6A6] uppercase tracking-wider">
                {isSi ? 'නිල ලිපිගොනු සහ Quotations සඳහා භාවිතා වන ව්‍යාපාරික තොරතුරු:' : 'Official Letterhead & Quotation Business Details:'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ව්‍යාපාරයේ නම (Business Name) *' : 'Business Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-bold focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ව්‍යාපාරික Tagline' : 'Brand Tagline'}
                  </label>
                  <input
                    type="text"
                    value={formData.tagline}
                    onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-[#FF7A00] font-extrabold focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ව්‍යාපාර ලියාපදිංචි අංකය (BR / PV Number)' : 'Company Registration No (BR / PV)'}
                  </label>
                  <input
                    type="text"
                    value={formData.companyRegistrationNo || ''}
                    onChange={(e) => setFormData({ ...formData, companyRegistrationNo: e.target.value })}
                    placeholder="PV-90481"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'VAT / TIN බදු අංකය (VAT No)' : 'VAT / TIN Tax Registration Number'}
                  </label>
                  <input
                    type="text"
                    value={formData.vatTinNumber || ''}
                    onChange={(e) => setFormData({ ...formData, vatTinNumber: e.target.value })}
                    placeholder="104829104-7000"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ලිපිනය (Physical Address)' : 'Official Business Address'}
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'නගරය / ප්‍රදේශය (City / Region)' : 'City / Area'}
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'WhatsApp / Hotline අංකය *' : 'WhatsApp Hotline Number *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.whatsappNumber}
                    onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono font-bold focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'පාරිභෝගික විමසීම් ඊමේල් ලිපිනය (Contact Email)' : 'Customer Support Email'}
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                {/* Admin Access Passcode */}
                <div className="sm:col-span-2 p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-1.5">
                  <label className="block text-xs font-bold text-white flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#FF7A00]" />
                    <span>{isSi ? 'Admin රහස්‍ය මුරපදය (Security Passcode) *' : 'Admin Security Passcode *'}</span>
                  </label>
                  <p className="text-[11px] text-neutral-400">
                    {isSi
                      ? 'පරිපාලක පුවරුවට (Admin Dashboard) පිවිසීම සඳහා මෙම මුරපදය අවශ්‍ය වේ.'
                      : 'Required to unlock the quotation management hub and price customer bids.'}
                  </p>
                  <input
                    type="text"
                    required
                    value={formData.adminPasscode}
                    onChange={(e) => setFormData({ ...formData, adminPasscode: e.target.value })}
                    className="w-full sm:w-64 px-3 py-1.5 text-xs bg-[#0B1F33] border border-neutral-600 rounded-lg text-white font-mono font-bold tracking-wider focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BANK DETAILS */}
          {activeTab === 'bank' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-1">
                <h3 className="text-xs font-bold text-[#00A6A6] uppercase tracking-wider flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4" />
                  <span>{isSi ? 'බැංකු ගිණුම් විස්තර (Letterhead Bank Remittance Details):' : 'Official Quotation Bank Remittance Details:'}</span>
                </h3>
                <p className="text-[11px] text-neutral-300">
                  {isSi
                    ? 'මෙම විස්තර පාරිභෝගිකයාට ලැබෙන නිල Office Depot Print PDF ලෙටර්හෙඩ් එකෙහි බැංකු ගෙවීම් විස්තර කොටසේ සෘජුවම දිස්වේ.'
                    : 'These banking remittance details will be dynamically rendered on the official Quotation PDF Letterhead.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'බැංකුවේ නම (Bank Name)' : 'Bank Name'}
                  </label>
                  <input
                    type="text"
                    value={formData.bankName || ''}
                    onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    placeholder="Commercial Bank of Ceylon PLC"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-semibold focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ශාඛාව (Branch)' : 'Branch Name'}
                  </label>
                  <input
                    type="text"
                    value={formData.bankBranch || ''}
                    onChange={(e) => setFormData({ ...formData, bankBranch: e.target.value })}
                    placeholder="Colombo Corporate Branch"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ගිණුමේ නම (Account Name / Payee)' : 'Account Name'}
                  </label>
                  <input
                    type="text"
                    value={formData.bankAccountName || ''}
                    onChange={(e) => setFormData({ ...formData, bankAccountName: e.target.value })}
                    placeholder="Office Depot Lanka (Pvt) Ltd"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-bold focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'ගිණුම් අංකය (Account Number)' : 'Account Number'}
                  </label>
                  <input
                    type="text"
                    value={formData.bankAccountNumber || ''}
                    onChange={(e) => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                    placeholder="1000 4829 1002"
                    className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono font-bold tracking-wider focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'SWIFT කේතය / බැංකු කේතය (SWIFT Code - විකල්ප)' : 'SWIFT / Clearing Code (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={formData.bankSwiftCode || ''}
                    onChange={(e) => setFormData({ ...formData, bankSwiftCode: e.target.value })}
                    placeholder="CCEYLKLX"
                    className="w-full sm:w-64 px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: EMAIL NOTIFICATIONS & GOOGLE SHEETS */}
          {activeTab === 'notifications' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Quotation Copy to Admin Email */}
              <div className="p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-[#FF7A00]" />
                    <h3 className="text-xs font-bold text-white">
                      {isSi ? 'එවන Quotation වල කොපි අපේ ඊමේල් එකට ලබාගැනීම (Email Alerts)' : 'Quotation Copy Email Alerts to Admin'}
                    </h3>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.enableEmailAlerts}
                      onChange={(e) => setFormData({ ...formData, enableEmailAlerts: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#00A6A6]"></div>
                  </label>
                </div>

                <p className="text-[11px] text-neutral-300">
                  {isSi
                    ? 'පාරිභෝගිකයෙකු ඕනෑම මිල කැඳවීමක් (RFQ) එවූ සැනින්, එහි සියලුම විස්තර සහ අයිටම් ලැයිස්තුව සහිත කොපියක් පහත ඊමේල් ලිපිනයට යොමු කෙරේ.'
                    : 'Instantly alerts your procurement inbox whenever a customer places a quotation inquiry.'}
                </p>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isSi ? 'Quotation කොපි ලැබිය යුතු ඔබගේ ඊමේල් ලිපිනය (Admin Inbox Email):' : 'Admin Receiving Email Address:'}
                  </label>
                  <input
                    type="email"
                    value={formData.adminNotificationEmail || ''}
                    onChange={(e) => setFormData({ ...formData, adminNotificationEmail: e.target.value })}
                    placeholder="owner@yourcompany.lk"
                    className="w-full px-3.5 py-2 text-xs bg-[#0B1F33] border border-neutral-600 rounded-lg text-white font-medium focus:outline-none focus:border-[#00A6A6]"
                  />
                </div>
              </div>

              {/* Google Sheets Webhook */}
              <div className="p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-2">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-bold text-white">
                    {isSi ? 'Google Sheets Apps Script Webhook URL' : 'Google Sheets Webhook Sync URL'}
                  </h3>
                </div>
                <p className="text-[11px] text-neutral-300">
                  {isSi
                    ? 'Google Sheet එකක් සමඟ සෘජුවම සම්බන්ධ කර ඇත්නම් එහි Webhook URL එක මෙහි paste කරන්න.'
                    : 'Stream new customer quotation rows directly into your connected Google Sheet.'}
                </p>
                <input
                  type="url"
                  value={formData.googleSheetsWebhookUrl || ''}
                  onChange={(e) => setFormData({ ...formData, googleSheetsWebhookUrl: e.target.value })}
                  placeholder="https://script.google.com/macros/s/.../exec"
                  className="w-full px-3.5 py-2 text-xs bg-[#0B1F33] border border-neutral-600 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                />
              </div>
            </div>
          )}

          {/* TAB 4: POP-UP ANNOUNCEMENT / AD (1:1 or 9:16) */}
          {activeTab === 'popup' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#FF7A00]" />
                    <h3 className="text-xs font-bold text-white">
                      {isSi ? 'වෙබ් අඩවියට පිවිසෙන විට Pop-up දැන්වීම් පෙන්වීම (Welcome Pop-up)' : 'Welcome Pop-up Announcement Modal'}
                    </h3>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.popupAdEnabled}
                      onChange={(e) => setFormData({ ...formData, popupAdEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#FF7A00]"></div>
                  </label>
                </div>

                <p className="text-[11px] text-neutral-300">
                  {isSi
                    ? 'පාරිභෝගිකයින් අඩවියට ආ සැණින් 1:1 (Square) හෝ 9:16 (Story) අනුපාතයෙන් ඡායාරූප හෝ වීඩියෝ සහිත දැන්වීමක් පෙන්විය හැක.'
                    : 'Display promotional banners or video teasers in 1:1 (Square) or 9:16 (Vertical Story) format on initial visit.'}
                </p>
              </div>

              {formData.popupAdEnabled && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Aspect Ratio Selector */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'දැන්වීමේ අනුපාතය (Aspect Ratio) *' : 'Ad Frame Aspect Ratio *'}
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, popupAdAspectRatio: '1:1' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                            formData.popupAdAspectRatio === '1:1'
                              ? 'border-[#00A6A6] bg-[#00A6A6]/20 text-[#00A6A6]'
                              : 'border-neutral-700 bg-[#071524] text-neutral-300 hover:text-white'
                          }`}
                        >
                          <span className="text-sm">🔲 1:1</span>
                          <span>{isSi ? 'Square (චතුරස්‍ර)' : 'Square (1:1)'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, popupAdAspectRatio: '9:16' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                            formData.popupAdAspectRatio === '9:16'
                              ? 'border-[#FF7A00] bg-[#FF7A00]/20 text-[#FF7A00]'
                              : 'border-neutral-700 bg-[#071524] text-neutral-300 hover:text-white'
                          }`}
                        >
                          <span className="text-sm">📱 9:16</span>
                          <span>{isSi ? 'Story (Vertical)' : 'Vertical Story (9:16)'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Media Type */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'මාධ්‍ය වර්ගය (Media Type)' : 'Media Format'}
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, popupAdMediaType: 'image' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            formData.popupAdMediaType === 'image'
                              ? 'border-[#00A6A6] bg-[#00A6A6]/20 text-[#00A6A6]'
                              : 'border-neutral-700 bg-[#071524] text-neutral-300'
                          }`}
                        >
                          <span>🖼️ {isSi ? 'Image (පින්තූර)' : 'Image'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, popupAdMediaType: 'video' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            formData.popupAdMediaType === 'video'
                              ? 'border-[#00A6A6] bg-[#00A6A6]/20 text-[#00A6A6]'
                              : 'border-neutral-700 bg-[#071524] text-neutral-300'
                          }`}
                        >
                          <span>🎥 {isSi ? 'Video (වීඩියෝ)' : 'Video'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Title */}
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'දැන්වීමේ ප්‍රධාන මාතෘකාව (Ad Title)' : 'Announcement Headline'}
                      </label>
                      <input
                        type="text"
                        value={formData.popupAdTitle || ''}
                        onChange={(e) => setFormData({ ...formData, popupAdTitle: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-bold focus:outline-none focus:border-[#00A6A6]"
                      />
                    </div>

                    {/* Subtitle */}
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'විස්තරය (Subtitle / Offer Details)' : 'Offer Description'}
                      </label>
                      <input
                        type="text"
                        value={formData.popupAdSubtitle || ''}
                        onChange={(e) => setFormData({ ...formData, popupAdSubtitle: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
                      />
                    </div>

                    {/* Media URL / Upload */}
                    <div className="sm:col-span-2 space-y-2">
                      <label className="block text-xs font-semibold text-neutral-300">
                        {isSi ? 'පින්තූරය හෝ වීඩියෝව (Image / Video URL හෝ Upload කරන්න):' : 'Media URL or Direct File Upload:'}
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={formData.popupAdMediaUrl || ''}
                          onChange={(e) => setFormData({ ...formData, popupAdMediaUrl: e.target.value })}
                          placeholder="https://... image.jpg or video.mp4"
                          className="flex-1 px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                        />

                        <label className="px-3.5 py-2 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shrink-0">
                          <Upload className="w-3.5 h-3.5" />
                          <span>{isSi ? 'Upload' : 'Upload File'}</span>
                          <input
                            type="file"
                            accept={formData.popupAdMediaType === 'video' ? 'video/*' : 'image/*'}
                            onChange={handleMediaUpload}
                            className="hidden"
                          />
                        </label>

                        <button
                          type="button"
                          onClick={() => setShowAdPreview(!showAdPreview)}
                          className="px-3 py-2 text-xs font-bold text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#FF7A00]" />
                          <span>{showAdPreview ? 'Hide' : 'Preview'}</span>
                        </button>
                      </div>
                    </div>

                    {/* CTA Button Text & Link */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'බොත්තමේ පාඨය (Button Text)' : 'Action Button Text'}
                      </label>
                      <input
                        type="text"
                        value={formData.popupAdCtaText || ''}
                        onChange={(e) => setFormData({ ...formData, popupAdCtaText: e.target.value })}
                        placeholder="Request Quotation Now"
                        className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-bold focus:outline-none focus:border-[#00A6A6]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        {isSi ? 'බොත්තමේ Link එක (Action Link / Target)' : 'Button Link / Anchor'}
                      </label>
                      <input
                        type="text"
                        value={formData.popupAdCtaLink || ''}
                        onChange={(e) => setFormData({ ...formData, popupAdCtaLink: e.target.value })}
                        placeholder="#rfq-form or https://..."
                        className="w-full px-3.5 py-2 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white font-mono focus:outline-none focus:border-[#00A6A6]"
                      />
                    </div>
                  </div>

                  {/* Live Ad Preview Frame */}
                  {showAdPreview && (
                    <div className="p-4 bg-[#071524] rounded-xl border border-neutral-700 space-y-3">
                      <span className="text-[11px] font-bold text-[#00A6A6] uppercase tracking-wider block">
                        Live Preview ({formData.popupAdAspectRatio}):
                      </span>
                      <div className="flex justify-center">
                        <div
                          className={`relative rounded-2xl overflow-hidden border-2 border-[#00A6A6] shadow-xl bg-black ${
                            formData.popupAdAspectRatio === '1:1'
                              ? 'w-64 h-64'
                              : 'w-48 h-80'
                          }`}
                        >
                          {formData.popupAdMediaType === 'video' ? (
                            <video
                              src={formData.popupAdMediaUrl}
                              autoPlay
                              loop
                              muted
                              playsInline
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img
                              src={formData.popupAdMediaUrl}
                              alt="Ad Preview"
                              className="w-full h-full object-cover"
                            />
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-[#0B1F33] via-transparent to-transparent pointer-events-none" />
                          <div className="absolute bottom-2 left-2 right-2 space-y-1">
                            <div className="text-xs font-bold text-white truncate">
                              {formData.popupAdTitle}
                            </div>
                            <div className="text-[10px] text-neutral-300 truncate">
                              {formData.popupAdSubtitle}
                            </div>
                            <div className="py-1 px-2 text-[10px] font-bold text-neutral-950 bg-[#FF7A00] rounded text-center">
                              {formData.popupAdCtaText}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* BOTTOM SAVE BAR */}
          <div className="pt-6 border-t border-neutral-800 flex items-center justify-between">
            <span className="text-xs text-neutral-400">
              {isSi ? '* සිදු කළ වෙනස්කම් සුරැකීමට Save Settings ඔබන්න.' : '* Click Save Settings to persist updates.'}
            </span>

            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-extrabold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isSi ? 'සැකසුම් සුරකින්න (Save Settings)' : 'Save Settings'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
