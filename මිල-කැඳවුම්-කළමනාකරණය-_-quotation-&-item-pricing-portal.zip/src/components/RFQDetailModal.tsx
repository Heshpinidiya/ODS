import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  Printer,
  MessageSquare,
  Mail,
  User,
  Phone,
  MapPin,
  Calendar,
  Send,
  Building,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Truck,
  CreditCard
} from 'lucide-react';
import { RFQRequest, RFQStatus, Language, OwnerSettings, QuotationPricingDetails } from '../types';
import {
  formatCurrency,
  formatNumber,
  formatFileSize,
  copyRFQToGoogleSheets,
  downloadRFQCSV,
  generateAdminQuoteWhatsAppUrl,
  generateAdminQuoteEmailUrl,
} from '../utils/exportUtils';

interface RFQDetailModalProps {
  rfq: RFQRequest | null;
  language: Language;
  ownerSettings: OwnerSettings;
  onClose: () => void;
  onUpdateQuotePricing: (
    id: string,
    items: RFQRequest['items'],
    pricing: QuotationPricingDetails,
    ownerNotes: string,
    status: RFQStatus
  ) => void;
  onOpenPrintView: (rfq: RFQRequest) => void;
}

export const RFQDetailModal: React.FC<RFQDetailModalProps> = ({
  rfq,
  language,
  ownerSettings,
  onClose,
  onUpdateQuotePricing,
  onOpenPrintView,
}) => {
  if (!rfq) return null;

  const isSi = language === 'si';
  const [copied, setCopied] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Editable prices per item
  const [items, setItems] = useState(
    rfq.items.map((it) => ({
      ...it,
      quotedUnitPrice: it.quotedUnitPrice || it.targetBudget || 0,
      quotedTotal: it.quotedTotal || (it.quotedUnitPrice || it.targetBudget || 0) * it.quantity,
    }))
  );

  // Pricing details
  const [discountPercent, setDiscountPercent] = useState<number>(rfq.pricing?.discountPercent || 0);
  const [taxPercent, setTaxPercent] = useState<number>(rfq.pricing?.taxPercent || 0);
  const [deliveryFee, setDeliveryFee] = useState<number>(rfq.pricing?.deliveryFee || 0);
  const [validDays, setValidDays] = useState<number>(rfq.pricing?.validDays || 14);
  const [deliveryEstimate, setDeliveryEstimate] = useState<string>(rfq.pricing?.deliveryEstimate || '2-3 Business Days');
  const [paymentTerms, setPaymentTerms] = useState<string>(rfq.pricing?.paymentTerms || 'Credit 30 Days on PO / Cash on Delivery');
  const [ownerNotes, setOwnerNotes] = useState<string>(rfq.ownerNotes || rfq.pricing?.notes || '');
  const [status, setStatus] = useState<RFQStatus>(rfq.status === 'new' ? 'quoted' : rfq.status);

  // Compute live totals
  const subtotal = items.reduce((sum, item) => sum + (item.quotedUnitPrice || 0) * item.quantity, 0);
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const taxable = subtotal - discountAmount;
  const taxAmount = Math.round((taxable * taxPercent) / 100);
  const grandTotal = taxable + taxAmount + (Number(deliveryFee) || 0);

  const handlePriceChange = (itemId: string, unitPrice: number) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== itemId) return it;
        return {
          ...it,
          quotedUnitPrice: unitPrice,
          quotedTotal: Math.round(unitPrice * it.quantity),
        };
      })
    );
  };

  const buildPricingObject = (): QuotationPricingDetails => ({
    subtotal,
    discountPercent,
    discountAmount,
    taxPercent,
    taxAmount,
    deliveryFee: Number(deliveryFee) || 0,
    grandTotal,
    validDays,
    deliveryEstimate,
    paymentTerms,
    notes: ownerNotes,
    quotedAt: new Date().toISOString(),
  });

  const handleSaveQuotation = async () => {
    setIsSaving(true);
    const pricingObj = buildPricingObject();
    await onUpdateQuotePricing(rfq.id, items, pricingObj, ownerNotes, status);
    setIsSaving(false);
    alert(isSi ? 'මිල ගණන් සාර්ථකව සුරැකිණි! දැන් පාරිභෝගිකයාටද මෙය පෙනෙනු ඇත.' : 'Quotation pricing saved! Customer can now track this quote.');
  };

  const handleSendWhatsApp = () => {
    const pricingObj = buildPricingObject();
    const updatedRfq: RFQRequest = {
      ...rfq,
      items,
      pricing: pricingObj,
      ourQuotedTotal: grandTotal,
      ownerNotes,
    };
    const url = generateAdminQuoteWhatsAppUrl(updatedRfq, ownerSettings);
    window.open(url, '_blank');
  };

  const handleSendEmail = () => {
    const pricingObj = buildPricingObject();
    const updatedRfq: RFQRequest = {
      ...rfq,
      items,
      pricing: pricingObj,
      ourQuotedTotal: grandTotal,
      ownerNotes,
    };
    const url = generateAdminQuoteEmailUrl(updatedRfq, ownerSettings);
    window.location.href = url;
  };

  const handleCopyTSV = async () => {
    const pricingObj = buildPricingObject();
    const success = await copyRFQToGoogleSheets({
      ...rfq,
      items,
      pricing: pricingObj,
    });
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleOpenPrint = () => {
    const pricingObj = buildPricingObject();
    const updatedRfq: RFQRequest = {
      ...rfq,
      items,
      pricing: pricingObj,
      ourQuotedTotal: grandTotal,
      ownerNotes,
      status,
    };
    onOpenPrintView(updatedRfq);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto no-print">
      <div className="bg-[#0B1F33] border border-neutral-700 text-white rounded-2xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Header Toolbar */}
        <div className="p-4 border-b border-neutral-800 bg-[#071524] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#00A6A6]/20 text-[#00A6A6] border border-[#00A6A6]/40">
              {rfq.referenceNumber || rfq.id}
            </span>
            <span className="text-xs text-neutral-400 font-mono-numbers">
              {new Date(rfq.createdAt).toLocaleString()}
            </span>
            {rfq.customer.urgency === 'urgent' && (
              <span className="text-xs font-bold text-[#FF7A00] bg-[#FF7A00]/10 border border-[#FF7A00]/40 px-2 py-0.5 rounded">
                ⚡ URGENT
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyTSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Sheets TSV'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenPrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-extrabold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isSi ? 'මුද්‍රණය කරන්න (Print PDF)' : 'Print PDF'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg ml-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Quotation Sheet */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-neutral-100 bg-[#0B1F33]">
          {/* Letterhead & Customer Info */}
          <div className="p-5 bg-[#071524] rounded-xl border border-neutral-800 flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div>
              <span className="text-xs font-bold text-[#00A6A6] uppercase tracking-widest block">
                OFFICE DEPOT CORPORATE RFQ
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">
                {rfq.customer.name}
              </h2>
              {rfq.customer.company && (
                <div className="text-xs text-[#FF7A00] font-semibold mt-0.5">
                  {rfq.customer.company}
                </div>
              )}
              <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-300 mt-2">
                <span className="flex items-center gap-1 font-mono-numbers">
                  <Phone className="w-3.5 h-3.5 text-[#00A6A6]" />
                  {rfq.customer.phone}
                </span>
                {rfq.customer.deliveryLocation && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#00A6A6]" />
                    {rfq.customer.deliveryLocation}
                  </span>
                )}
                {rfq.customer.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-[#00A6A6]" />
                    {rfq.customer.email}
                  </span>
                )}
              </div>
            </div>

            {/* Customer Direct Contact Link */}
            <div className="flex flex-col sm:items-end gap-2 shrink-0">
              <span className="text-[11px] text-neutral-400">
                {isSi ? 'පාරිභෝගිකයාගේ WhatsApp අංකය:' : 'Customer WhatsApp:'}
              </span>
              <a
                href={`https://wa.me/${rfq.customer.phone.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat with Customer</span>
              </a>
            </div>
          </div>

          {/* Customer Uploaded Files (Excel, PDF, Images) */}
          {rfq.attachments && rfq.attachments.length > 0 && (
            <div className="p-4 bg-[#071524] rounded-xl border border-neutral-800 space-y-2">
              <span className="text-xs font-bold text-[#00A6A6] uppercase tracking-wider block">
                {isSi ? 'පාරිභෝගිකයා Upload කළ ලිපිගොනු (Customer Attachments):' : 'Attached Customer Files:'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {rfq.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2.5 bg-[#0B1F33] rounded-lg border border-neutral-700 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      {att.type === 'excel' ? (
                        <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : att.type === 'pdf' ? (
                        <FileText className="w-4 h-4 text-red-400 shrink-0" />
                      ) : (
                        <ImageIcon className="w-4 h-4 text-blue-400 shrink-0" />
                      )}
                      <span className="truncate font-medium text-white">{att.name}</span>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        ({formatFileSize(att.size)})
                      </span>
                    </div>

                    {att.dataUrl && (
                      <a
                        href={att.dataUrl}
                        download={att.name}
                        className="px-2 py-1 text-[11px] font-semibold text-[#00A6A6] hover:underline shrink-0"
                      >
                        Download
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Itemized Pricing Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                {isSi ? 'අපගේ ඒකක මිල ගණන් පිරවීම (Set Our Quoted Unit Prices):' : 'Item Pricing Breakdown:'}
              </h3>
              <span className="text-xs text-neutral-400">
                {items.length} {isSi ? 'භාණ්ඩ' : 'items'}
              </span>
            </div>

            <div className="border border-neutral-700 rounded-xl overflow-hidden bg-[#071524]">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#0B1F33] text-neutral-300 font-semibold border-b border-neutral-700">
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">{isSi ? 'භාණ්ඩය සහ අවශ්‍යතා' : 'Item & Specifications'}</th>
                    <th className="py-2.5 px-3 w-20 text-center">{isSi ? 'ඒකකය' : 'Unit'}</th>
                    <th className="py-2.5 px-3 w-20 text-right">{isSi ? 'ප්‍රමාණය' : 'Qty'}</th>
                    <th className="py-2.5 px-3 w-32 text-right">{isSi ? 'Target Budget' : 'Target Budget'}</th>
                    <th className="py-2.5 px-3 w-36 text-right bg-[#00A6A6]/20 text-white font-bold border-l border-r border-[#00A6A6]/40">
                      {isSi ? 'අපගේ මිල (LKR)' : 'Our Unit Price (LKR)'}
                    </th>
                    <th className="py-2.5 px-3 w-32 text-right">{isSi ? 'එකතුව (LKR)' : 'Line Total (LKR)'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800">
                  {items.map((item, idx) => {
                    const price = item.quotedUnitPrice || 0;
                    const total = price * item.quantity;
                    return (
                      <tr key={item.id} className="hover:bg-neutral-800/40">
                        <td className="py-2.5 px-3 text-center text-neutral-500 font-mono-numbers">
                          {idx + 1}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-white">{item.name}</div>
                          {item.specs && (
                            <div className="text-[11px] text-neutral-400 mt-0.5">{item.specs}</div>
                          )}
                          {item.remarks && (
                            <div className="text-[11px] text-[#FF7A00] italic mt-0.5">Note: {item.remarks}</div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center text-neutral-300">
                          {item.unit}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono-numbers font-semibold text-white">
                          {formatNumber(item.quantity)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-400">
                          {item.targetBudget ? `රු. ${formatNumber(item.targetBudget)}` : '-'}
                        </td>
                        <td className="py-2 px-2 bg-neutral-800/30 text-right border-l border-r border-neutral-700">
                          <input
                            type="number"
                            min="0"
                            placeholder="0.00"
                            value={item.quotedUnitPrice || ''}
                            onChange={(e) => handlePriceChange(item.id, parseFloat(e.target.value) || 0)}
                            className="w-full px-2.5 py-1 text-right text-xs bg-white border border-[#00A6A6] rounded text-neutral-950 focus:outline-none focus:ring-2 focus:ring-[#00A6A6] font-mono-numbers font-extrabold shadow-sm"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono-numbers font-bold text-emerald-400">
                          {formatNumber(total)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quotation Commercial Terms and Totals */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
            {/* Terms input */}
            <div className="space-y-3 bg-[#071524] p-4 rounded-xl border border-neutral-800 text-xs">
              <span className="font-bold text-[#00A6A6] uppercase tracking-wider block">
                {isSi ? 'පාරිභෝගිකයාට ඉදිරිපත් කරන කොන්දේසි (Terms & Validity):' : 'Commercial Terms:'}
              </span>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 mb-1">
                    {isSi ? 'වලංගු කාලය (Validity):' : 'Quotation Validity:'}
                  </label>
                  <input
                    type="number"
                    value={validDays}
                    onChange={(e) => setValidDays(parseInt(e.target.value, 10) || 14)}
                    className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-neutral-950 font-mono-numbers font-bold"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 mb-1">
                    {isSi ? 'බෙදාහැරීමේ කාලය:' : 'Delivery Estimate:'}
                  </label>
                  <input
                    type="text"
                    value={deliveryEstimate}
                    onChange={(e) => setDeliveryEstimate(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-neutral-950 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">
                  {isSi ? 'ගෙවීම් ක්‍රමය (Payment Terms):' : 'Payment Terms:'}
                </label>
                <input
                  type="text"
                  value={paymentTerms}
                  onChange={(e) => setPaymentTerms(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-neutral-950 font-semibold"
                />
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">
                  {isSi ? 'පාරිභෝගිකයාට සටහන් (Notes to Customer):' : 'Special Notes:'}
                </label>
                <textarea
                  rows={2}
                  value={ownerNotes}
                  onChange={(e) => setOwnerNotes(e.target.value)}
                  placeholder="Free assembly, 2 years warranty, credit terms approved..."
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded text-neutral-950 font-medium resize-none placeholder-neutral-400"
                />
              </div>
            </div>

            {/* Calculations Box */}
            <div className="bg-[#071524] p-4 rounded-xl border border-neutral-800 space-y-2.5 text-xs">
              <span className="font-bold text-[#FF7A00] uppercase tracking-wider block">
                {isSi ? 'අවසාන මිල ගණන් එකතුව (Quotation Summary):' : 'Pricing Summary:'}
              </span>

              <div className="flex justify-between text-neutral-300">
                <span>Subtotal:</span>
                <span className="font-mono-numbers font-semibold">
                  {formatCurrency(subtotal)}
                </span>
              </div>

              <div className="flex items-center justify-between text-neutral-300">
                <div className="flex items-center gap-1.5">
                  <span>Discount (%):</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={discountPercent || ''}
                    onChange={(e) => setDiscountPercent(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-16 px-1.5 py-0.5 text-right bg-white border border-neutral-300 rounded text-neutral-950 font-mono-numbers font-bold"
                  />
                </div>
                <span className="font-mono-numbers text-neutral-400">
                  - {formatCurrency(discountAmount)}
                </span>
              </div>

              <div className="flex items-center justify-between text-neutral-300">
                <div className="flex items-center gap-1.5">
                  <span>Delivery Fee (රු.):</span>
                  <input
                    type="number"
                    min="0"
                    value={deliveryFee || ''}
                    onChange={(e) => setDeliveryFee(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-24 px-1.5 py-0.5 text-right bg-white border border-neutral-300 rounded text-neutral-950 font-mono-numbers font-bold"
                  />
                </div>
                <span className="font-mono-numbers text-neutral-400">
                  + {formatCurrency(deliveryFee)}
                </span>
              </div>

              <div className="pt-2 border-t border-neutral-700 flex justify-between items-baseline">
                <span className="text-sm font-bold text-white uppercase tracking-wider">
                  Grand Total:
                </span>
                <span className="text-xl font-extrabold font-mono-numbers text-[#00A6A6]">
                  {formatCurrency(grandTotal)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM ACTION BAR: SEND VIA WHATSAPP / EMAIL / SAVE */}
        <div className="p-4 bg-[#071524] border-t border-neutral-800 flex flex-wrap items-center justify-between gap-3 shrink-0 no-print">
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-400">{isSi ? 'තත්වය:' : 'Status:'}</span>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as RFQStatus)}
              className="text-xs bg-white border border-neutral-300 rounded-lg px-2.5 py-1.5 text-neutral-950 font-bold"
            >
              <option value="new">New (නව)</option>
              <option value="quoted">Quoted (මිල ගණන් යැව්වා)</option>
              <option value="completed">Completed (තහවුරු විය)</option>
              <option value="cancelled">Cancelled (අවලංගුයි)</option>
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Save quote */}
            <button
              type="button"
              onClick={handleSaveQuotation}
              disabled={isSaving}
              className="px-4 py-2 text-xs font-bold text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              {isSaving ? 'සුරැකෙමින්...' : (isSi ? 'මිල සුරකින්න' : 'Save Pricing')}
            </button>

            {/* SEND VIA EMAIL */}
            <button
              type="button"
              onClick={handleSendEmail}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{isSi ? 'Email යවන්න' : 'Send Email'}</span>
            </button>

            {/* DIRECT WHATSAPP PROPOSAL SEND */}
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg shadow-md transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>{isSi ? 'WhatsApp මඟින් පාරිභෝගිකයාට මිල යවන්න' : 'Send Quotation to WhatsApp'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
