import React, { useState } from 'react';
import { Search, X, CheckCircle2, Clock, FileText, Download, MessageSquare, Printer, Tag, Building, Phone } from 'lucide-react';
import { RFQRequest, Language, OwnerSettings } from '../types';
import { formatNumber, formatCurrency, downloadRFQCSV } from '../utils/exportUtils';

interface CustomerTrackModalProps {
  isOpen: boolean;
  language: Language;
  ownerSettings: OwnerSettings;
  onClose: () => void;
  onOpenPrintView?: (rfq: RFQRequest) => void;
}

export const CustomerTrackModal: React.FC<CustomerTrackModalProps> = ({
  isOpen,
  language,
  ownerSettings,
  onClose,
  onOpenPrintView,
}) => {
  if (!isOpen) return null;

  const isSi = language === 'si';
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<RFQRequest | null>(null);
  const [notFound, setNotFound] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setNotFound(false);
    setResult(null);

    try {
      const res = await fetch(`/api/rfq/track/${encodeURIComponent(query.trim())}`);
      const data = await res.json();
      if (res.ok && data.success && data.rfq) {
        setResult(data.rfq);
      } else {
        setNotFound(true);
      }
    } catch (err) {
      setNotFound(true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#0B1F33] border border-neutral-700 rounded-2xl max-w-2xl w-full p-6 text-white shadow-2xl relative animate-in fade-in zoom-in-95 my-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4">
          <span className="text-[11px] font-bold text-[#00A6A6] tracking-wider uppercase block">
            {isSi ? 'පාරිභෝගික තත්ව පරීක්ෂාව' : 'QUOTATION STATUS TRACKER'}
          </span>
          <h3 className="text-xl font-bold text-white mt-0.5">
            {isSi ? 'ඔබගේ මිල කැඳවුමේ තත්වය පරීක්ෂා කරන්න' : 'Track Your Quotation Request'}
          </h3>
          <p className="text-xs text-neutral-300 mt-1">
            {isSi
              ? 'ඔබට ලැබුණු Reference අංකය (උදා: OD-RFQ-8421) හෝ දුරකථන අංකය ඇතුළත් කර අපගේ මිල ගණන් සහ ප්‍රගතිය බලන්න.'
              : 'Enter your Reference ID (e.g. OD-RFQ-8421) or registered phone number to check pricing status.'}
          </p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2 mb-5">
          <input
            type="text"
            required
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isSi ? 'OD-RFQ-8421 හෝ දුරකථන අංකය...' : 'OD-RFQ-8421 or 077XXXXXXX...'}
            className="flex-1 px-4 py-2.5 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6] font-mono tracking-wider"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-5 py-2.5 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Search className="w-4 h-4" />
            <span>{isLoading ? (isSi ? 'සොයමින්...' : 'Searching...') : (isSi ? 'පරීක්ෂා කරන්න' : 'Track Quote')}</span>
          </button>
        </form>

        {notFound && (
          <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-lg text-xs text-red-300 text-center">
            {isSi
              ? 'මෙම අංකයට අදාළව මිල කැඳවීමක් හමු නොවීය. කරුණාකර අංකය නිවැරදිදැයි පරීක්ෂා කරන්න.'
              : 'No quotation request found with this Reference ID or Phone number. Please check and try again.'}
          </div>
        )}

        {result && (
          <div className="bg-[#071524] border border-neutral-700 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-800">
              <div>
                <span className="text-[11px] text-neutral-400 block font-mono">
                  {result.referenceNumber || result.id}
                </span>
                <span className="text-sm font-bold text-white">
                  {result.customer.name} {result.customer.company ? `(${result.customer.company})` : ''}
                </span>
              </div>

              <div>
                {result.status === 'quoted' ? (
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isSi ? 'මිල ගණන් සූදානම්! (Quoted)' : 'Quotation Ready!'}</span>
                  </span>
                ) : result.status === 'completed' ? (
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-blue-500/20 text-blue-400 font-bold border border-blue-500/40">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isSi ? 'තහවුරු විය (Confirmed)' : 'Order Confirmed'}</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{isSi ? 'සලකා බලමින් පවතී (Reviewing)' : 'Under Pricing Review'}</span>
                  </span>
                )}
              </div>
            </div>

            {/* Quoted Pricing Table if available */}
            <div>
              <h4 className="text-xs font-semibold text-neutral-300 mb-2">
                {isSi ? 'භාණ්ඩ සහ මිල විස්තර (Item Breakdown):' : 'Item Quotation Details:'}
              </h4>
              <div className="border border-neutral-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#0B1F33] text-neutral-400 font-semibold border-b border-neutral-800">
                      <th className="py-2 px-3">#</th>
                      <th className="py-2 px-3">{isSi ? 'භාණ්ඩය' : 'Item'}</th>
                      <th className="py-2 px-2 text-right">{isSi ? 'ප්‍රමාණය' : 'Qty'}</th>
                      <th className="py-2 px-3 text-right">{isSi ? 'අපේ ඒකක මිල' : 'Unit Price'}</th>
                      <th className="py-2 px-3 text-right">{isSi ? 'එකතුව' : 'Total'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800 text-neutral-200">
                    {result.items.map((item, idx) => {
                      const price = item.quotedUnitPrice || 0;
                      const total = item.quotedTotal || price * item.quantity;
                      return (
                        <tr key={item.id}>
                          <td className="py-2 px-3 text-neutral-500 font-mono-numbers">{idx + 1}</td>
                          <td className="py-2 px-3">
                            <span className="font-medium text-white block">{item.name}</span>
                            {item.specs && <span className="text-[11px] text-neutral-400">{item.specs}</span>}
                          </td>
                          <td className="py-2 px-2 text-right font-mono-numbers">{item.quantity} {item.unit}</td>
                          <td className="py-2 px-3 text-right font-mono-numbers text-emerald-400">
                            {price > 0 ? `රු. ${formatNumber(price)}` : (isSi ? 'සලකා බලයි' : 'Pending')}
                          </td>
                          <td className="py-2 px-3 text-right font-mono-numbers font-bold text-white">
                            {total > 0 ? `රු. ${formatNumber(total)}` : '-'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Grand Total banner if quoted */}
            {result.pricing ? (
              <div className="p-3 bg-[#0B1F33] border border-[#00A6A6]/40 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-xs text-neutral-400 block">{isSi ? 'මුළු මිල කැඳවීම:' : 'Quotation Total:'}</span>
                  <span className="text-lg font-bold font-mono-numbers text-white">
                    රු. {formatNumber(result.pricing.grandTotal)}
                  </span>
                </div>
                {result.pricing.deliveryEstimate && (
                  <div className="text-right text-xs text-neutral-300">
                    <span>{isSi ? 'බෙදාහැරීම:' : 'Delivery:'} <strong>{result.pricing.deliveryEstimate}</strong></span>
                  </div>
                )}
              </div>
            ) : null}

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-800">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => downloadRFQCSV(result)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isSi ? 'CSV බාගත' : 'CSV'}</span>
                </button>

                {onOpenPrintView && (result.pricing || result.status === 'quoted' || result.status === 'completed') && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenPrintView(result);
                      onClose();
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-neutral-950 bg-white hover:bg-neutral-100 rounded transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-[#00A6A6]" />
                    <span>{isSi ? 'නිල Quotation PDF මුද්‍රණය' : 'Print Official PDF'}</span>
                  </button>
                )}
              </div>

              <a
                href={`https://wa.me/${ownerSettings.whatsappNumber.replace(/\D/g, '')}?text=${encodeURIComponent(`Hello Office Depot! Regarding my quotation request [${result.referenceNumber || result.id}]:`)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#1ab8b8] rounded transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{isSi ? 'WhatsApp හරහා කතා කරන්න' : 'Chat with Office Depot'}</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
