import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, Play, Eye } from 'lucide-react';
import { OwnerSettings, Language } from '../types';

interface PromoPopupAdModalProps {
  settings: OwnerSettings;
  language: Language;
  onClose: () => void;
  onActionClick?: () => void;
}

export const PromoPopupAdModal: React.FC<PromoPopupAdModalProps> = ({
  settings,
  language,
  onClose,
  onActionClick,
}) => {
  const isSi = language === 'si';
  const [dontShowAgain, setDontShowAgain] = useState(false);

  if (!settings.popupAdEnabled) return null;

  const isSquare = settings.popupAdAspectRatio === '1:1';
  const isVideo = settings.popupAdMediaType === 'video';
  const mediaUrl = settings.popupAdMediaUrl || 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80';

  const handleClose = () => {
    if (dontShowAgain && typeof window !== 'undefined') {
      sessionStorage.setItem('od_popup_dismissed', 'true');
    }
    onClose();
  };

  const handleAction = () => {
    handleClose();
    if (onActionClick) {
      onActionClick();
    } else if (settings.popupAdCtaLink) {
      if (settings.popupAdCtaLink.startsWith('#')) {
        const el = document.querySelector(settings.popupAdCtaLink);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.open(settings.popupAdCtaLink, '_blank');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-300">
      <div
        className={`relative bg-[#0B1F33] border-2 border-[#00A6A6] text-white rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto transition-all duration-300 ${
          isSquare
            ? 'w-full max-w-md'
            : 'w-full max-w-sm max-h-[90vh]'
        }`}
      >
        {/* Floating Close Button */}
        <button
          type="button"
          onClick={handleClose}
          className="absolute top-3 right-3 z-30 p-2 bg-black/60 hover:bg-black/90 text-white rounded-full backdrop-blur-sm transition-transform active:scale-95 cursor-pointer shadow-lg"
          title="Close announcement"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Aspect Ratio Media Container (1:1 or 9:16) */}
        <div
          className={`relative w-full overflow-hidden bg-neutral-950 ${
            isSquare ? 'aspect-square' : 'aspect-[9/16]'
          }`}
        >
          {isVideo ? (
            <video
              src={mediaUrl}
              autoPlay
              loop
              muted
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={mediaUrl}
              alt={settings.popupAdTitle || 'Office Depot Promotion'}
              className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
            />
          )}

          {/* Gradient Overlay for Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B1F33] via-[#0B1F33]/40 to-transparent pointer-events-none" />

          {/* Top Badge */}
          <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0B1F33]/90 border border-[#00A6A6] text-[#00A6A6] text-[11px] font-extrabold uppercase tracking-wider backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#FF7A00]" />
            <span>SPECIAL ANNOUNCEMENT</span>
          </div>

          {/* Media Info Overlay at Bottom of Media */}
          <div className="absolute bottom-3 left-4 right-4 z-20 space-y-1">
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight drop-shadow-md leading-tight">
              {settings.popupAdTitle || 'Office Depot Promotional Offer'}
            </h3>
            {settings.popupAdSubtitle && (
              <p className="text-xs sm:text-sm text-neutral-200 font-medium drop-shadow-sm line-clamp-2">
                {settings.popupAdSubtitle}
              </p>
            )}
          </div>
        </div>

        {/* Action Panel & Bottom Controls */}
        <div className="p-4 sm:p-5 bg-[#0B1F33] space-y-3.5 border-t border-neutral-800">
          <button
            type="button"
            onClick={handleAction}
            className="w-full py-3 px-5 text-sm font-extrabold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
          >
            <span>{settings.popupAdCtaText || (isSi ? 'මිල කැඳවුමක් ඉල්ලුම් කරන්න' : 'Request Quotation Now')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none hover:text-neutral-200">
              <input
                type="checkbox"
                checked={dontShowAgain}
                onChange={(e) => setDontShowAgain(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-neutral-800 border-neutral-700 text-[#00A6A6] focus:ring-0 cursor-pointer"
              />
              <span>{isSi ? 'අද දිනය තුළ නැවත නොපෙන්වන්න' : "Don't show again today"}</span>
            </label>

            <button
              type="button"
              onClick={handleClose}
              className="text-neutral-400 hover:text-white underline cursor-pointer"
            >
              {isSi ? 'පසුව බලන්න' : 'Skip'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
