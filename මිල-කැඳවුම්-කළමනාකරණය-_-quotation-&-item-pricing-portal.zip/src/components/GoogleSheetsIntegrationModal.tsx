import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Copy,
  Check,
  ExternalLink,
  Download,
  Code,
  Zap,
  Sparkles,
} from 'lucide-react';
import { Language, RFQRequest, OwnerSettings } from '../types';
import {
  copyAllRFQsToGoogleSheets,
  downloadAllRFQsCSV,
} from '../utils/exportUtils';

interface GoogleSheetsIntegrationProps {
  language: Language;
  rfqs: RFQRequest[];
  ownerSettings: OwnerSettings;
  onSaveWebhookUrl: (url: string) => void;
}

export const GoogleSheetsIntegration: React.FC<GoogleSheetsIntegrationProps> = ({
  language,
  rfqs,
  ownerSettings,
  onSaveWebhookUrl,
}) => {
  const isSi = language === 'si';
  const [copiedFormula, setCopiedFormula] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const [webhookInput, setWebhookInput] = useState(ownerSettings.googleSheetsWebhookUrl || '');
  const [webhookSaved, setWebhookSaved] = useState(false);

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com';
  const importDataFormula = `=IMPORTDATA("${currentOrigin}/api/rfq/export/all.csv")`;

  const appsScriptCode = `// 1. Open Google Sheets and go to Extensions > Apps Script.
// 2. Paste this code and Save.
// 3. Click Deploy > New Deployment > Web app. Set "Who has access" to "Anyone".
// 4. Copy the Web App URL and paste into Office Depot Webhook settings.

function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Ref ID",
      "Date & Time",
      "Customer Name",
      "Company",
      "Phone / WhatsApp",
      "Delivery Location",
      "Urgency",
      "Required Items Breakdown",
      "Quoted Grand Total",
      "Status"
    ]);
  }
  
  var itemsText = data.items.map(function(item, idx) {
    var specs = item.specs ? " [" + item.specs + "]" : "";
    var budget = item.targetBudget ? " (Budget: " + item.targetBudget + ")" : "";
    return (idx + 1) + ". " + item.name + " (" + item.quantity + " " + item.unit + ")" + specs + budget;
  }).join("\\n");
  
  sheet.appendRow([
    data.referenceNumber || data.id,
    new Date(data.createdAt).toLocaleString(),
    data.customer.name,
    data.customer.company || "-",
    data.customer.phone,
    data.customer.deliveryLocation,
    data.customer.urgency.toUpperCase(),
    itemsText,
    data.ourQuotedTotal || "-",
    "NEW"
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({"status": "success"})).setMimeType(ContentService.MimeType.JSON);
}`;

  const handleCopyFormula = async () => {
    await navigator.clipboard.writeText(importDataFormula);
    setCopiedFormula(true);
    setTimeout(() => setCopiedFormula(false), 2500);
  };

  const handleCopyScript = async () => {
    await navigator.clipboard.writeText(appsScriptCode);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  const handleCopyAllToSheets = async () => {
    const success = await copyAllRFQsToGoogleSheets(rfqs);
    if (success) {
      setCopiedAll(true);
      setTimeout(() => setCopiedAll(false), 2500);
    }
  };

  const handleSaveWebhook = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveWebhookUrl(webhookInput);
    setWebhookSaved(true);
    setTimeout(() => setWebhookSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Hero Banner */}
      <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-6 shadow-xl">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#00A6A6]/20 border border-[#00A6A6] text-[#00A6A6] flex items-center justify-center shrink-0">
            <FileSpreadsheet className="w-7 h-7" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#FF7A00] tracking-wider uppercase block">
              GOOGLE SHEETS MASTER ADMIN
            </span>
            <h1 className="text-2xl font-bold text-white tracking-tight mt-0.5">
              {isSi ? 'Google Sheets ඔබගේ Admin Panel එක කරගැනීම' : 'Manage All Quotations in Google Sheets'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1">
              {isSi
                ? 'පාරිභෝගිකයා වෙබ් පිටුවේ ටයිප් කරන ඕනෑම භාණ්ඩ ලැයිස්තුවක් සෘජුවම ඔබගේ Google Sheet එකට පේළි වශයෙන් ඇතුළත් වේ.'
                : 'Automate quotation logging directly into your personal Google Sheet with live formulas or instant webhooks.'}
            </p>
          </div>
        </div>

        {/* 1-Click Action Bar */}
        <div className="mt-6 pt-5 border-t border-neutral-800 flex flex-wrap items-center gap-3">
          <a
            href="https://sheets.new"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl shadow-md transition-colors cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" />
            <span>{isSi ? '1. Google Sheet එකක් අරින්න (sheets.new)' : '1. Open Blank Google Sheet'}</span>
          </a>

          <button
            type="button"
            onClick={handleCopyAllToSheets}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-xl transition-colors cursor-pointer"
          >
            {copiedAll ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copiedAll ? 'දත්ත පිටපත් විය!' : (isSi ? '2. දත්ත සියල්ල Copy කරගන්න (Copy TSV)' : '2. Copy All Data to Clipboard')}</span>
          </button>

          <button
            type="button"
            onClick={() => downloadAllRFQsCSV(rfqs)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-neutral-400" />
            <span>Download CSV</span>
          </button>
        </div>
      </div>

      {/* 2 Main Approaches */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Method A: Live =IMPORTDATA Formula */}
        <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-5 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                {isSi ? 'ක්‍රමය 01 (සූත්‍රය)' : 'Approach 01 (Formula)'}
              </span>
              <Zap className="w-4 h-4 text-[#FF7A00]" />
            </div>
            <h3 className="text-base font-bold text-white">
              {isSi ? '=IMPORTDATA සජීවී සූත්‍රය' : 'Live =IMPORTDATA Auto-Sync'}
            </h3>
            <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
              {isSi
                ? 'ඔබගේ Google Sheet එකේ A1 කොටුවේ පහත සූත්‍රය ඇතුළත් කරන්න. නව මිල කැඳවුම් ලැබෙන විට Sheet එක ස්වයංක්‍රීයව update වේ.'
                : 'Paste this formula in cell A1 of any Google Sheet for continuous real-time quotation fetching.'}
            </p>

            <div className="mt-3 p-3 bg-[#071524] text-[#00A6A6] rounded-xl text-xs font-mono break-all border border-neutral-800">
              {importDataFormula}
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={handleCopyFormula}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-xl transition-colors cursor-pointer"
            >
              {copiedFormula ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedFormula ? 'Copied!' : (isSi ? 'සූත්‍රය Copy කරගන්න' : 'Copy Formula')}</span>
            </button>
          </div>
        </div>

        {/* Method B: Real-Time Webhook */}
        <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-5 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                {isSi ? 'ක්‍රමය 02 (සජීවී Webhook)' : 'Approach 02 (Instant Webhook)'}
              </span>
              <Sparkles className="w-4 h-4 text-[#00A6A6]" />
            </div>
            <h3 className="text-base font-bold text-white">
              {isSi ? 'Google Sheet එකටම සෘජුවම Row එකක් ලියවීම' : 'Real-Time Sheet Row Insertion'}
            </h3>
            <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
              {isSi
                ? 'පාරිභෝගිකයා Submit බොත්තම එබූ සැනින් ඔබගේ Google Sheet එකේ අලුත් පේළියක් ලෙස පාරිභෝගිකයාගේ නම, දුරකථනය, සහ භාණ්ඩ සටහන් වේ.'
                : 'Customer submits form -> immediately appends a brand new row to your Google Sheet using Apps Script.'}
            </p>

            <form onSubmit={handleSaveWebhook} className="mt-3 space-y-2">
              <label className="block text-[11px] font-semibold text-neutral-300">
                {isSi ? 'ඔබගේ Google Apps Script Web App URL එක:' : 'Your Apps Script Web App URL:'}
              </label>
              <input
                type="url"
                value={webhookInput}
                onChange={(e) => setWebhookInput(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full px-2.5 py-1.5 text-xs bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6] font-mono"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
              >
                {webhookSaved ? <Check className="w-3.5 h-3.5" /> : null}
                <span>{webhookSaved ? 'සුරැකිණි!' : 'Save Webhook URL'}</span>
              </button>
            </form>
          </div>

          <div className="pt-4 mt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={handleCopyScript}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl transition-colors cursor-pointer"
            >
              {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedScript ? 'Script Copied!' : 'Copy Apps Script Code'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Code Display */}
      <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-6 shadow-xl space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Code className="w-4 h-4 text-[#00A6A6]" />
          <span>{isSi ? 'Apps Script කේතය (Google Sheets Editor එකට Paste කරන්න):' : 'Ready-to-Use Google Apps Script:'}</span>
        </h3>

        <pre className="p-4 bg-[#071524] text-neutral-200 rounded-xl text-xs font-mono overflow-x-auto max-h-56 border border-neutral-800">
          {appsScriptCode}
        </pre>
      </div>
    </div>
  );
};
