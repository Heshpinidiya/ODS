import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Copy,
  Send,
  MessageSquare,
  FileSpreadsheet,
  Download,
  Sparkles,
  ClipboardPaste,
  Building,
  User,
  Phone,
  MapPin,
  Clock,
  CheckCircle2,
  Check,
  AlertCircle,
  Upload,
  File,
  FileText,
  Image as ImageIcon,
  X,
  Search,
  Mail,
  HeartHandshake
} from 'lucide-react';
import { RFQItem, RFQRequest, Language, OwnerSettings, UrgencyLevel, UploadedAttachment } from '../types';
import {
  formatNumber,
  formatFileSize,
  generateCustomerWhatsAppUrl,
  generateAdminRfqAlertEmailUrl,
  copyRFQToGoogleSheets,
  downloadRFQCSV,
} from '../utils/exportUtils';

interface CustomerRFQFormProps {
  language: Language;
  ownerSettings: OwnerSettings;
  onRequestSubmitted: (rfq: RFQRequest) => void;
  onOpenTrackModal: () => void;
  onOpenAdminLogin: () => void;
}

const COMMON_UNITS = [
  'Pcs (කෑලි)',
  'Nos (ගණන)',
  'Boxes (පෙට්ටි)',
  'Reams (රීම්)',
  'Packs (පැකට්)',
  'Cartons (කාටන්)',
  'Sets (කට්ටල)',
  'Units (ඒකක)',
  'Rolls (රෝල්)',
  'Kg (කිලෝග්‍රෑම්)',
  'Meters (මීටර්)',
];

const PRESET_TEMPLATES = [
  {
    name: '📄 කාර්යාලීය ලිපිද්‍රව්‍ය (Office Stationery)',
    items: [
      { id: 'p-1', name: 'Double A / JK A4 Copier Paper (80 GSM)', specs: 'Box of 5 Reams, High White', quantity: 20, unit: 'Boxes', targetBudget: 7800, remarks: 'Immediate delivery' },
      { id: 'p-2', name: 'Atlas Chooty Ballpoint Pens (Black/Blue)', specs: 'Box of 50 pens', quantity: 8, unit: 'Boxes', targetBudget: 1200, remarks: 'Equal mix' },
      { id: 'p-3', name: 'Heavy Duty Box Files (3-inch spine)', specs: 'Metal corners, label spine', quantity: 25, unit: 'Pcs', targetBudget: 550, remarks: 'Black / Blue' },
    ]
  },
  {
    name: '🖨️ Toner & Printer Cartridges',
    items: [
      { id: 'p-4', name: 'HP LaserJet 85A Toner Cartridge (CE285A)', specs: 'Original Genuine with Security Seal', quantity: 5, unit: 'Pcs', targetBudget: 18500, remarks: 'For HP P1102' },
      { id: 'p-5', name: 'Canon 303 / 703 Compatible Black Toner', specs: 'Premium grade, high yield 2000 pages', quantity: 4, unit: 'Pcs', targetBudget: 5400, remarks: 'Tested quality' },
    ]
  },
  {
    name: '🪑 Office Furniture & Ergonomics',
    items: [
      { id: 'p-6', name: 'Ergonomic Mesh High-Back Chair', specs: 'Adjustable Lumbar Support & Armrests', quantity: 6, unit: 'Pcs', targetBudget: 32000, remarks: 'Black frame' },
      { id: 'p-7', name: 'Dual Monitor Desk Mount Clamp', specs: 'Full Motion Gas Spring 17-32 inch', quantity: 4, unit: 'Pcs', targetBudget: 11500, remarks: 'Heavy duty' },
    ]
  }
];

export const CustomerRFQForm: React.FC<CustomerRFQFormProps> = ({
  language,
  ownerSettings,
  onRequestSubmitted,
  onOpenTrackModal,
  onOpenAdminLogin,
}) => {
  const isSi = language === 'si';

  // Customer Contact Fields
  const [customerName, setCustomerName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('normal');
  const [requiredDate, setRequiredDate] = useState('');
  const [notes, setNotes] = useState('');

  // Item List State
  const [items, setItems] = useState<RFQItem[]>([
    { id: 'item-1', name: '', specs: '', quantity: 1, unit: 'Pcs', targetBudget: undefined, remarks: '' },
    { id: 'item-2', name: '', specs: '', quantity: 1, unit: 'Pcs', targetBudget: undefined, remarks: '' },
    { id: 'item-3', name: '', specs: '', quantity: 1, unit: 'Pcs', targetBudget: undefined, remarks: '' },
  ]);

  // Uploaded Files State (Excel, PDF, Images, Quotes)
  const [attachments, setAttachments] = useState<UploadedAttachment[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // Bulk paste modal
  const [showBulkPaste, setShowBulkPaste] = useState(false);
  const [bulkText, setBulkText] = useState('');

  // Submission Status
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRfq, setSubmittedRfq] = useState<RFQRequest | null>(null);
  const [copiedReference, setCopiedReference] = useState(false);

  const updateItem = (id: string, field: keyof RFQItem, val: any) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        return { ...item, [field]: val };
      })
    );
  };

  const addItemRow = () => {
    setItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}-${prev.length + 1}`,
        name: '',
        specs: '',
        quantity: 1,
        unit: 'Pcs',
        targetBudget: undefined,
        remarks: '',
      },
    ]);
  };

  const removeItemRow = (id: string) => {
    if (items.length <= 1) {
      setItems([{ id: `item-${Date.now()}`, name: '', specs: '', quantity: 1, unit: 'Pcs', remarks: '' }]);
      return;
    }
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const applyPreset = (presetItems: RFQItem[]) => {
    setItems(presetItems);
  };

  // Handle File Uploads (Excel, PDF, Image, Doc)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const newAttachments: UploadedAttachment[] = [];

    Array.from(files).forEach((file) => {
      let fileType: UploadedAttachment['type'] = 'other';
      const nameLower = file.name.toLowerCase();

      if (nameLower.endsWith('.xlsx') || nameLower.endsWith('.xls') || nameLower.endsWith('.csv')) {
        fileType = 'excel';
      } else if (nameLower.endsWith('.pdf')) {
        fileType = 'pdf';
      } else if (nameLower.match(/\.(jpg|jpeg|png|webp|gif)$/)) {
        fileType = 'image';
      } else if (nameLower.endsWith('.doc') || nameLower.endsWith('.docx')) {
        fileType = 'doc';
      }

      const reader = new FileReader();
      reader.onload = () => {
        newAttachments.push({
          id: `att-${Date.now()}-${Math.random()}`,
          name: file.name,
          size: file.size,
          type: fileType,
          dataUrl: reader.result as string,
        });

        if (newAttachments.length === files.length) {
          setAttachments((prev) => [...prev, ...newAttachments]);
          setIsUploading(false);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleBulkPaste = () => {
    if (!bulkText.trim()) return;
    const lines = bulkText.split('\n');
    const newItems: RFQItem[] = [];

    lines.forEach((line, idx) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      const cols = trimmed.includes('\t') ? trimmed.split('\t') : trimmed.split(',');
      const name = cols[0]?.trim() || `Item ${idx + 1}`;
      const specs = cols[1]?.trim() || '';
      const qty = parseFloat(cols[2]?.trim() || '1') || 1;
      const unit = cols[3]?.trim() || 'Pcs';
      const budget = parseFloat(cols[4]?.trim() || '') || undefined;

      newItems.push({
        id: `bulk-${Date.now()}-${idx}`,
        name,
        specs,
        quantity: qty,
        unit,
        targetBudget: budget,
        remarks: '',
      });
    });

    if (newItems.length > 0) {
      setItems(newItems);
      setBulkText('');
      setShowBulkPaste(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim()) {
      alert(isSi ? 'කරුණාකර ඔබගේ නම ඇතුළත් කරන්න.' : 'Please enter your name.');
      return;
    }
    if (!phone.trim()) {
      alert(isSi ? 'කරුණාකර ඔබගේ දුරකථන හෝ WhatsApp අංකය ඇතුළත් කරන්න.' : 'Please enter your phone or WhatsApp number.');
      return;
    }

    const validItems = items.filter((i) => i.name.trim() !== '');
    if (validItems.length === 0 && attachments.length === 0) {
      alert(isSi ? 'කරුණාකර අවම වශයෙන් එක් භාණ්ඩයක නම ටයිප් කරන්න හෝ Excel / PDF ලැයිස්තුවක් upload කරන්න.' : 'Please type at least one item or upload an item document.');
      return;
    }

    const randomId = `OD-RFQ-${Math.floor(1000 + Math.random() * 9000)}`;

    const rfqData: RFQRequest = {
      id: randomId,
      referenceNumber: randomId,
      createdAt: new Date().toISOString(),
      status: 'new',
      customer: {
        name: customerName,
        company: companyName,
        phone,
        email,
        deliveryLocation: deliveryLocation || 'Colombo Delivery',
        urgency,
        requiredDate,
        notes,
      },
      items: validItems.length > 0 ? validItems : [{ id: 'att-only', name: 'Document Attached Items List', quantity: 1, unit: 'File' }],
      attachments,
    };

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/rfq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rfqData),
      });

      if (res.ok) {
        const data = await res.json();
        onRequestSubmitted(data.rfq);
        setSubmittedRfq(data.rfq);
      } else {
        onRequestSubmitted(rfqData);
        setSubmittedRfq(rfqData);
      }
    } catch (err) {
      onRequestSubmitted(rfqData);
      setSubmittedRfq(rfqData);
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyRefCode = async (ref: string) => {
    await navigator.clipboard.writeText(ref);
    setCopiedReference(true);
    setTimeout(() => setCopiedReference(false), 2500);
  };

  const resetForm = () => {
    setCustomerName('');
    setCompanyName('');
    setPhone('');
    setEmail('');
    setDeliveryLocation('');
    setNotes('');
    setRequiredDate('');
    setAttachments([]);
    setItems([
      { id: `it-${Date.now()}-1`, name: '', specs: '', quantity: 1, unit: 'Pcs', remarks: '' },
      { id: `it-${Date.now()}-2`, name: '', specs: '', quantity: 1, unit: 'Pcs', remarks: '' },
    ]);
    setSubmittedRfq(null);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* BINANCE-INSPIRED HERO BRAND CARD (Deep Navy #0B1F33, Teal #00A6A6, Orange #FF7A00) */}
      <div className="bg-[#0B1F33] text-white rounded-2xl p-6 sm:p-8 border border-neutral-800 shadow-xl relative overflow-hidden">
        {/* Subtle geometric gradient backdrop */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#00A6A6]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#FF7A00]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-[#00A6A6]/20 text-[#00A6A6] border border-[#00A6A6]/40 uppercase tracking-wider">
                {isSi ? 'ගිණුමක් අවශ්‍ය නැත (No Login)' : 'B2B Procurement Portal'}
              </span>
              <span className="text-xs text-neutral-400 font-medium">
                ⚡ {isSi ? `පැය ${ownerSettings.responsePromiseHours}ක් තුළ නිල මිල කැඳවීමක්` : `Official Quote within ${ownerSettings.responsePromiseHours} Hours`}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Office Depot Quotation Portal
            </h1>
            <p className="text-xs sm:text-sm font-bold tracking-widest text-[#FF7A00] uppercase">
              REQUEST. QUOTE. DELIVER.
            </p>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-2xl leading-relaxed pt-1">
              {isSi
                ? 'ඔබගේ කාර්යාලයට, ව්‍යාපාරයට හෝ ව්‍යාපෘතියට අවශ්‍ය ඕනෑම ලිපිද්‍රව්‍ය, පරිගණක උපාංග හෝ භාණ්ඩ ලැයිස්තුව ටයිප් කරන්න හෝ Excel / PDF ගොනුවක් upload කරන්න. අපගේ නිල මිල ගණන් කෙලින්ම ඔබගේ WhatsApp වෙත සපයන්නෙමු.'
                : 'Type your bill of materials, stationery or equipment list, or simply upload an Excel/PDF document. Receive competitive corporate pricing directly to WhatsApp and Email.'}
            </p>
          </div>

          {/* Quick Tracking Button for Customers who already have a code */}
          <div className="shrink-0 flex flex-row md:flex-col gap-2">
            <button
              type="button"
              onClick={onOpenTrackModal}
              className="px-4 py-2 text-xs font-bold text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-lg transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <Search className="w-3.5 h-3.5 text-[#00A6A6]" />
              <span>{isSi ? 'මිල කැඳවුම Track කරන්න' : 'Track Existing Quote'}</span>
            </button>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Customer Contact Details */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs">
          <h2 className="text-sm font-bold text-[#0B1F33] uppercase tracking-wider mb-4 flex items-center gap-2">
            <User className="w-4 h-4 text-[#00A6A6]" />
            <span>{isSi ? '1. ඔබගේ තොරතුරු (Contact Details)' : '1. Contact Information'}</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'ඔබගේ නම (Your Name) *' : 'Your Name *'}
              </label>
              <input
                type="text"
                required
                placeholder={isSi ? 'උදා: කසුන් පෙරේරා' : 'e.g. Kasun Perera'}
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-bold border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'ආයතනය / ව්‍යාපාරික නම (Company)' : 'Company Name (Optional)'}
              </label>
              <input
                type="text"
                placeholder={isSi ? 'උදා: පෙරේරා ලොජිස්ටික්ස්' : 'e.g. Acme Tech Pvt Ltd'}
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-semibold border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'දුරකථන / WhatsApp අංකය *' : 'Phone / WhatsApp Number *'}
              </label>
              <input
                type="text"
                required
                placeholder="0771234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-mono-numbers font-bold border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'භාණ්ඩ ලබාගත යුතු ලිපිනය / නගරය (Delivery Location)' : 'Delivery Address / City'}
              </label>
              <input
                type="text"
                placeholder={isSi ? 'උදා: කොළඹ 03 / නාවල' : 'e.g. Colombo 03 Office'}
                value={deliveryLocation}
                onChange={(e) => setDeliveryLocation(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-semibold border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'අවශ්‍යතාවයේ කඩිනම් බව (Urgency)' : 'Urgency Level'}
              </label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-bold border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              >
                <option value="urgent">⚡ {isSi ? 'ඉතා කඩිනම් (Urgent - පැය 24-48ක් තුළ)' : 'Urgent (Within 24-48 Hours)'}</option>
                <option value="normal">📅 {isSi ? 'සාමාන්‍ය (Normal - දින 3-5ක් ඇතුළත)' : 'Normal (3-5 Days)'}</option>
                <option value="flexible">⏳ {isSi ? 'දිනයක් නියම කර නැත (Flexible)' : 'Flexible / Planning Stage'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {isSi ? 'විද්‍යුත් තැපෑල (Email - විකල්ප)' : 'Email Address (Optional)'}
              </label>
              <input
                type="email"
                placeholder="purchasing@company.lk"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white text-neutral-950 font-medium border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] shadow-xs"
              />
            </div>
          </div>
        </div>

        {/* Step 2: Items List to Type */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div>
              <h2 className="text-sm font-bold text-[#0B1F33] uppercase tracking-wider flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-[#00A6A6]" />
                <span>{isSi ? '2. අවශ්‍ය භාණ්ඩ ලැයිස්තුව ටයිප් කරන්න (Manual Item List)' : '2. Required Items List'}</span>
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                {isSi
                  ? 'අවශ්‍ය භාණ්ඩ, ප්‍රමාණයන් සහ Brand/Model ඇතුළත් කරන්න.'
                  : 'Type product names, quantities, and specifications below.'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setShowBulkPaste(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors cursor-pointer"
              >
                <ClipboardPaste className="w-3.5 h-3.5 text-blue-600" />
                <span>{isSi ? 'Excel වලින් Paste කරන්න' : 'Paste from Excel'}</span>
              </button>

              <button
                type="button"
                onClick={addItemRow}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#15bfbf] rounded-md shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isSi ? '+ නව පේළියක් (Add Item)' : '+ Add Item'}</span>
              </button>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="mb-4 p-3 bg-neutral-50 border border-neutral-200 rounded-lg flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold text-neutral-700">
              {isSi ? 'කඩිනම් ආකෘති (Presets):' : 'Sample Templates:'}
            </span>
            {PRESET_TEMPLATES.map((tmpl) => (
              <button
                key={tmpl.name}
                type="button"
                onClick={() => applyPreset(tmpl.items)}
                className="px-2.5 py-1 bg-white border border-neutral-300 hover:border-[#00A6A6] rounded text-neutral-700 hover:text-[#00A6A6] font-medium transition-colors cursor-pointer"
              >
                {tmpl.name}
              </button>
            ))}
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-neutral-200 rounded-lg">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#0B1F33] text-white font-semibold">
                  <th className="py-2.5 px-2.5 w-10 text-center">#</th>
                  <th className="py-2.5 px-3 min-w-[220px]">{isSi ? 'අවශ්‍ය භාණ්ඩයේ නම (Item Name) *' : 'Item Name *'}</th>
                  <th className="py-2.5 px-3 min-w-[180px]">{isSi ? 'විශේෂ අවශ්‍යතා / Brand (Specifications)' : 'Specifications / Brand / Model'}</th>
                  <th className="py-2.5 px-2.5 w-24 text-right">{isSi ? 'ප්‍රමාණය *' : 'Qty *'}</th>
                  <th className="py-2.5 px-2.5 w-28">{isSi ? 'ඒකකය' : 'Unit'}</th>
                  <th className="py-2.5 px-2.5 w-32 text-right">{isSi ? 'අපේක්ෂිත මිල (Budget)' : 'Target Budget (LKR)'}</th>
                  <th className="py-2.5 px-2 w-12 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {items.map((item, index) => (
                  <tr key={item.id} className="hover:bg-neutral-50/70 transition-colors">
                    <td className="py-2.5 px-2.5 text-center text-neutral-400 font-mono-numbers">
                      {index + 1}
                    </td>
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder={isSi ? 'උදා: Double A A4 Paper, HP 85A Toner...' : 'Product / item name'}
                        value={item.name}
                        onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs bg-white text-neutral-950 font-bold border border-neutral-300 rounded focus:border-[#00A6A6] focus:ring-1 focus:ring-[#00A6A6] focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder={isSi ? 'උදා: Original HP, High White 80gsm...' : 'Model, brand or grade preferences'}
                        value={item.specs || ''}
                        onChange={(e) => updateItem(item.id, 'specs', e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs bg-white text-neutral-950 font-medium border border-neutral-300 rounded focus:border-[#00A6A6] focus:ring-1 focus:ring-[#00A6A6] focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2.5 text-right">
                      <input
                        type="number"
                        min="0.1"
                        step="any"
                        value={item.quantity || ''}
                        onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 1)}
                        className="w-full px-2 py-1.5 text-xs text-right bg-white text-neutral-950 font-mono-numbers font-extrabold border border-neutral-300 rounded focus:border-[#00A6A6] focus:ring-1 focus:ring-[#00A6A6] focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2.5">
                      <input
                        list={`units-rfq-${item.id}`}
                        value={item.unit}
                        onChange={(e) => updateItem(item.id, 'unit', e.target.value)}
                        className="w-full px-2 py-1.5 text-xs bg-white text-neutral-950 font-bold border border-neutral-300 rounded focus:border-[#00A6A6] focus:ring-1 focus:ring-[#00A6A6] focus:outline-none"
                      />
                      <datalist id={`units-rfq-${item.id}`}>
                        {COMMON_UNITS.map((u) => (
                          <option key={u} value={u.split(' ')[0]} />
                        ))}
                      </datalist>
                    </td>
                    <td className="py-2.5 px-2.5 text-right">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder={isSi ? 'විකල්ප (රු.)' : 'Optional'}
                        value={item.targetBudget || ''}
                        onChange={(e) => updateItem(item.id, 'targetBudget', parseFloat(e.target.value) || undefined)}
                        className="w-full px-2 py-1.5 text-xs text-right bg-white text-neutral-950 font-mono-numbers font-bold border border-neutral-300 rounded focus:border-[#00A6A6] focus:ring-1 focus:ring-[#00A6A6] focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      <button
                        type="button"
                        onClick={() => removeItemRow(item.id)}
                        title="Delete row"
                        className="p-1 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between mt-3 text-xs text-neutral-500">
            <span>
              {items.length} {isSi ? 'භාණ්ඩ පේළි' : 'item row(s)'}
            </span>
            <button
              type="button"
              onClick={addItemRow}
              className="text-[#00A6A6] hover:underline font-bold inline-flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>{isSi ? 'තවත් භාණ්ඩයක් එක් කරන්න' : 'Add another item'}</span>
            </button>
          </div>
        </div>

        {/* Step 3: FILE UPLOADS (Excel, PDF, Images, Quotations) */}
        <div className="bg-white border border-neutral-200 rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-[#0B1F33] uppercase tracking-wider flex items-center gap-2">
              <Upload className="w-4 h-4 text-[#00A6A6]" />
              <span>{isSi ? '3. ලිපිගොනු Upload කිරීම (Excel, PDF, Images, Reference Quotes)' : '3. Attach Documents & Reference Files'}</span>
            </h2>
            <span className="text-xs text-neutral-400">
              {isSi ? 'විකල්ප (Optional)' : 'Optional'}
            </span>
          </div>

          <p className="text-xs text-neutral-500 mb-4">
            {isSi
              ? 'ඔබ සතුව දැනටමත් සකස් කළ Excel භාණ්ඩ ලැයිස්තුවක්, PDF ලිපියක්, පෙර මිල කැඳවීමක් හෝ භාණ්ඩ ඡායාරූප ඇත්නම් මෙහි upload කරන්න.'
              : 'Upload existing Excel sheets (.xlsx, .csv), PDF RFQ specifications, reference quotations or product photos.'}
          </p>

          <div className="border-2 border-dashed border-neutral-300 hover:border-[#00A6A6] rounded-xl p-6 text-center bg-neutral-50/50 transition-colors">
            <input
              type="file"
              id="file-upload-input"
              multiple
              accept=".xlsx,.xls,.csv,.pdf,.jpg,.jpeg,.png,.webp,.doc,.docx"
              onChange={handleFileUpload}
              className="hidden"
            />
            <label
              htmlFor="file-upload-input"
              className="cursor-pointer flex flex-col items-center justify-center space-y-2"
            >
              <div className="w-12 h-12 rounded-full bg-[#00A6A6]/10 text-[#00A6A6] flex items-center justify-center">
                <Upload className="w-6 h-6" />
              </div>
              <div className="text-xs font-semibold text-neutral-800">
                {isUploading ? (isSi ? 'ගොනු එක්වෙමින් පවතී...' : 'Uploading...') : (isSi ? 'ලිපිගොනු මෙහි drag කරන්න හෝ Browse කරන්න' : 'Click to Browse or Drag & Drop Files')}
              </div>
              <div className="text-[11px] text-neutral-400">
                Excel (.xlsx, .csv), PDF (.pdf), Images (.png, .jpg), Word (.docx) — Max 25MB
              </div>
            </label>
          </div>

          {/* Uploaded Files List */}
          {attachments.length > 0 && (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center justify-between p-2.5 bg-neutral-100 rounded-lg border border-neutral-200 text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    {att.type === 'excel' ? (
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : att.type === 'pdf' ? (
                      <FileText className="w-4 h-4 text-red-600 shrink-0" />
                    ) : att.type === 'image' ? (
                      <ImageIcon className="w-4 h-4 text-blue-600 shrink-0" />
                    ) : (
                      <File className="w-4 h-4 text-neutral-600 shrink-0" />
                    )}
                    <span className="truncate font-medium text-neutral-800">{att.name}</span>
                    <span className="text-[10px] text-neutral-400 font-mono shrink-0">
                      ({formatFileSize(att.size)})
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeAttachment(att.id)}
                    className="p-1 text-neutral-400 hover:text-red-600 rounded transition-colors ml-2 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Special Instructions */}
          <div className="mt-4 pt-4 border-t border-neutral-200">
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              {isSi ? 'අමතර සටහන් / විශේෂ උපදෙස් (Delivery & Payment Instructions)' : 'Additional Notes / Instructions'}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={isSi ? 'උදා: හෝටලයට / සයිට් එකටම ගෙනවිත් දිය යුතුයි, බිල්පත (Invoice) අවශ්‍යයි...' : 'Special requirements, delivery instructions, unloading requirements...'}
              className="w-full px-3.5 py-2 text-xs bg-white text-neutral-950 font-medium border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A6A6] resize-none"
            />
          </div>
        </div>

        {/* SUBMIT BUTTON BAR (Orange CTA #FF7A00, High Contrast) */}
        <div className="bg-[#0B1F33] text-white rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-neutral-800">
          <div>
            <span className="text-xs font-bold text-[#FF7A00] tracking-wider uppercase block">
              OFFICE DEPOT PROMISE
            </span>
            <h3 className="text-base font-bold text-white mt-0.5">
              {isSi ? 'මිල කැඳවුම් ඉල්ලුම්පත යැවීමට සූදානම්ද?' : 'Ready to Submit Quotation Request?'}
            </h3>
            <p className="text-xs text-neutral-300 mt-1">
              {isSi
                ? 'ඔබගේ ඉල්ලුම්පත ලැබුණු සැනින් Reference Code එකක් ලැබෙන අතර, Google Sheet සහ WhatsApp වෙත තොරතුරු යොමු වේ.'
                : '100% Free corporate pricing service. Immediate Reference Number generated.'}
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-extrabold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl shadow-lg transition-all disabled:opacity-50 whitespace-nowrap cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>
              {isSubmitting
                ? (isSi ? 'යවමින් පවතී...' : 'Submitting...')
                : (isSi ? 'මිල කැඳවීමක් ඉල්ලුම් කරන්න' : 'SUBMIT QUOTATION REQUEST')}
            </span>
          </button>
        </div>
      </form>

      {/* HEARTFELT THANK YOU CONFIRMATION MODAL WITH REFERENCE NUMBER & MULTI-CHANNEL DISPATCH */}
      {submittedRfq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
          <div className="bg-[#0B1F33] border-2 border-[#00A6A6] rounded-3xl max-w-lg w-full p-6 sm:p-8 text-white shadow-2xl space-y-5 animate-in fade-in zoom-in-95 my-auto">
            {/* Heartfelt Thank You Header Icon */}
            <div className="relative mx-auto w-16 h-16 rounded-full bg-[#00A6A6]/20 border-2 border-[#00A6A6] text-[#00A6A6] flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-9 h-9" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#FF7A00] text-neutral-950 flex items-center justify-center text-xs font-black shadow-sm">
                ✓
              </div>
            </div>

            <div className="text-center space-y-1.5">
              <span className="inline-block px-3 py-1 rounded-full bg-[#FF7A00]/20 text-[#FF7A00] border border-[#FF7A00]/40 text-xs font-black uppercase tracking-widest">
                💐 {isSi ? 'බොහොම ස්තූතියි!' : 'THANK YOU VERY MUCH!'}
              </span>
              <h3 className="text-2xl font-black text-white tracking-tight">
                {isSi ? 'ඔබගේ මිල කැඳවුම අප වෙත ලැබිණි!' : 'Quotation Request Received!'}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed pt-1">
                {isSi
                  ? `ගරු ${submittedRfq.customer.name} මැතිතුමනි / මැතිණියනි, ${ownerSettings.businessName} තෝරාගැනීම පිළිබඳව අපගේ හෘදයාංගම ස්තූතිය! ඔබ ඉල්ලූ භාණ්ඩ ${submittedRfq.items.length} සඳහා අපගේ නිල මිල ගණන් පැය ${ownerSettings.responsePromiseHours}ක් තුළ ඔබගේ WhatsApp වෙත සපයන්නෙමු.`
                  : `Dear ${submittedRfq.customer.name}, thank you for choosing ${ownerSettings.businessName}! We have received your inquiry for ${submittedRfq.items.length} item(s) and will send our official proposal within ${ownerSettings.responsePromiseHours} hours.`}
              </p>
            </div>

            {/* REFERENCE NUMBER BADGE WITH 1-CLICK COPY */}
            <div className="p-4 bg-[#071524] rounded-2xl border border-neutral-700 text-center space-y-1.5">
              <span className="text-[11px] text-neutral-400 uppercase tracking-wider block font-semibold">
                {isSi ? 'ඔබගේ සුවිශේෂී Reference අංකය (Keep this ID to track):' : 'Your Unique Reference Tracking ID:'}
              </span>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-black font-mono text-[#00A6A6] tracking-wider">
                  {submittedRfq.referenceNumber || submittedRfq.id}
                </span>
                <button
                  type="button"
                  onClick={() => copyRefCode(submittedRfq.referenceNumber || submittedRfq.id)}
                  className="p-1.5 text-neutral-400 hover:text-white bg-neutral-800 rounded-lg transition-colors cursor-pointer"
                  title="Copy Reference Code"
                >
                  {copiedReference ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <span className="text-[11px] text-neutral-400 block">
                {isSi ? 'මෙම අංකය භාවිතයෙන් වෙබ් අඩවිය හරහා ඕනෑම මොහොතක ප්‍රගතිය බැලිය හැක.' : 'Track your quotation status anytime using this reference code.'}
              </span>
            </div>

            {/* EMAIL ALERT CONFIRMATION */}
            {ownerSettings.adminNotificationEmail && (
              <div className="p-3 bg-[#071524] rounded-xl border border-neutral-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-neutral-300">
                  <Mail className="w-4 h-4 text-[#00A6A6] shrink-0" />
                  <span className="text-[11px]">
                    {isSi ? 'Quotation පිටපතක් ප්‍රසම්පාදන අංශයේ ඊමේල් වෙත යොමු විය:' : 'A copy has been routed to procurement desk:'}
                  </span>
                </div>
                <span className="font-mono text-[11px] font-bold text-neutral-300 truncate max-w-[150px]">
                  {ownerSettings.adminNotificationEmail}
                </span>
              </div>
            )}

            {/* INSTANT WHATSAPP SEND TO OFFICE DEPOT */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-bold text-neutral-200 block text-center">
                {isSi ? '💬 කඩිනම් ප්‍රතිචාරයක් සඳහා දැන්ම අපගේ WhatsApp වෙත යවන්න:' : '💬 Forward direct to Office Depot WhatsApp Hotline:'}
              </span>
              <a
                href={generateCustomerWhatsAppUrl(submittedRfq, ownerSettings.whatsappNumber)}
                target="_blank"
                rel="noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-black text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-xl shadow-lg transition-all cursor-pointer active:scale-[0.99]"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{isSi ? 'WhatsApp මඟින් දැන්ම යවන්න' : 'Send via WhatsApp Hotline'}</span>
              </a>
            </div>

            {/* Secondary Actions: Email Copy / CSV / New Request */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => downloadRFQCSV(submittedRfq)}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isSi ? 'CSV බාගත' : 'Download Copy'}</span>
              </button>

              <button
                type="button"
                onClick={resetForm}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-neutral-950 bg-white hover:bg-neutral-100 rounded-xl transition-colors cursor-pointer"
              >
                <span>{isSi ? 'නව එකක් සාදන්න' : 'Submit Another'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Paste Modal */}
      {showBulkPaste && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-[#0B1F33] border border-neutral-700 text-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ClipboardPaste className="w-4 h-4 text-[#00A6A6]" />
                <span>{isSi ? 'Excel හෝ Google Sheets වලින් Rows Copy-Paste කරන්න' : 'Bulk Paste from Excel / Google Sheets'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowBulkPaste(false)}
                className="text-neutral-400 hover:text-white text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-neutral-300">
              {isSi
                ? 'ඔබගේ spreadsheet එකේ Columns (භාණ්ඩයේ නම, Brand/Specs, ප්‍රමාණය, ඒකකය, අපේක්ෂිත මිල) copy කර පහත කොටුවට paste (Ctrl+V) කරන්න:'
                : 'Copy rows directly from Excel or Google Sheets (Columns: Name, Specs, Quantity, Unit, Budget) and paste below:'}
            </p>

            <textarea
              rows={6}
              value={bulkText}
              onChange={(e) => setBulkText(e.target.value)}
              placeholder="Double A A4 Paper	80 GSM Box	25	Boxes	7800&#10;HP 85A Toner	Original CE285A	4	Pcs	18500&#10;Box Files	3-inch spine	30	Pcs	550"
              className="w-full p-3 text-xs font-mono bg-[#071524] border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-[#00A6A6]"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowBulkPaste(false)}
                className="px-3.5 py-1.5 text-xs text-neutral-400 hover:text-white rounded-lg cursor-pointer"
              >
                {isSi ? 'අවලංගු කරන්න' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleBulkPaste}
                disabled={!bulkText.trim()}
                className="px-5 py-1.5 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg disabled:opacity-50 cursor-pointer"
              >
                {isSi ? 'භාණ්ඩ ඇතුළත් කරන්න' : 'Import Items'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
