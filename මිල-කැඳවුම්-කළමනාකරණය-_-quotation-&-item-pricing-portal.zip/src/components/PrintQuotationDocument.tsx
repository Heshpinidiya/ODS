import React from 'react';
import { Printer, X, Download, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { RFQRequest, OwnerSettings, Language } from '../types';
import { formatNumber, formatCurrency } from '../utils/exportUtils';

interface PrintQuotationDocumentProps {
  rfq: RFQRequest;
  ownerSettings: OwnerSettings;
  language: Language;
  onClose: () => void;
}

// Converts number to words (basic English currency text)
function numberToWordsLKR(amount: number): string {
  if (!amount || amount === 0) return 'Zero Rupees';
  const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertChunk(n: number): string {
    let str = '';
    if (n >= 100) {
      str += units[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      str += tens[Math.floor(n / 10)] + ' ';
      n %= 10;
    }
    if (n > 0) {
      str += units[n] + ' ';
    }
    return str.trim();
  }

  let num = Math.floor(amount);
  let words = '';

  if (num >= 10000000) {
    words += convertChunk(Math.floor(num / 10000000)) + ' Crore ';
    num %= 10000000;
  }
  if (num >= 100000) {
    words += convertChunk(Math.floor(num / 100000)) + ' Lakh ';
    num %= 100000;
  }
  if (num >= 1000) {
    words += convertChunk(Math.floor(num / 1000)) + ' Thousand ';
    num %= 1000;
  }
  if (num > 0) {
    words += convertChunk(num);
  }

  return `Sri Lankan Rupees ${words.trim()} Only`;
}

export const PrintQuotationDocument: React.FC<PrintQuotationDocumentProps> = ({
  rfq,
  ownerSettings,
  language,
  onClose,
}) => {
  const isSi = language === 'si';
  const pricing = rfq.pricing;

  const subtotal = pricing
    ? pricing.subtotal
    : rfq.items.reduce((s, it) => s + (it.quotedUnitPrice || it.targetBudget || 0) * it.quantity, 0);

  const discountAmount = pricing ? pricing.discountAmount : 0;
  const deliveryFee = pricing ? pricing.deliveryFee : 0;
  const grandTotal = pricing ? pricing.grandTotal : (rfq.ourQuotedTotal || subtotal);

  const validDays = pricing?.validDays || 14;
  const deliveryEstimate = pricing?.deliveryEstimate || '2-3 Business Days';
  const paymentTerms = pricing?.paymentTerms || 'Credit 30 Days on Official Purchase Order';

  const handlePrint = () => {
    // 1. First attempt standard window.print()
    try {
      window.print();
    } catch (e) {
      console.warn('Standard window.print failed, attempting iframe print:', e);
      printViaIframe();
    }
  };

  const printViaIframe = () => {
    const printContent = document.getElementById('printable-quotation-view');
    if (!printContent) return;

    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc) return;

    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${rfq.referenceNumber || rfq.id} - ${ownerSettings.businessName}</title>
          <style>
            @page { size: A4 portrait; margin: 8mm 10mm 10mm 10mm; }
            * { box-sizing: border-box; }
            body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 10px; color: #000000; background: #ffffff; font-size: 11pt; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #d1d5db; padding: 6px 8px; text-align: left; }
            th { background: #0B1F33; color: #ffffff; }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .font-mono { font-family: monospace; }
            .font-bold { font-weight: bold; }
            .border-b-2 { border-bottom: 2px solid #0B1F33; }
            .grid { display: grid; }
            .grid-cols-2 { grid-template-columns: 1fr 1fr; }
            .gap-6 { gap: 24px; }
            .py-6 { padding-top: 18px; padding-bottom: 18px; }
            .mt-1 { margin-top: 4px; }
            .mt-2 { margin-top: 8px; }
            .mb-1 { margin-bottom: 4px; }
            .uppercase { text-transform: uppercase; }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    doc.close();

    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 2000);
    }, 500);
  };

  const handleDownloadHTML = () => {
    const printContent = document.getElementById('printable-quotation-view');
    if (!printContent) return;

    const fullHtml = `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>${rfq.referenceNumber || rfq.id} - ${ownerSettings.businessName}</title>
    <style>
      @page { size: A4 portrait; margin: 8mm 10mm 10mm 10mm; }
      body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 25px; color: #000000; background: #ffffff; font-size: 11pt; max-width: 800px; margin: 0 auto; }
      table { width: 100%; border-collapse: collapse; margin: 15px 0; }
      th, td { border: 1px solid #d1d5db; padding: 8px 10px; font-size: 10pt; }
      th { background-color: #0B1F33; color: #ffffff; text-align: left; }
      .text-right { text-align: right; }
      .text-center { text-align: center; }
      .font-mono { font-family: monospace; }
      .font-bold { font-weight: bold; }
    </style>
  </head>
  <body>
    ${printContent.innerHTML}
    <script>
      window.onload = function() { window.print(); };
    </script>
  </body>
</html>`;

    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${rfq.referenceNumber || rfq.id}_quotation.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="print-container-root fixed inset-0 z-50 bg-neutral-900/90 overflow-y-auto flex flex-col items-center p-0 sm:p-4 print:p-0 print:bg-white print:static print:overflow-visible">
      {/* Top Floating Control Bar (Hidden on print) */}
      <div className="no-print sticky top-0 z-50 w-full max-w-4xl bg-[#0B1F33] text-white p-3.5 rounded-none sm:rounded-xl shadow-xl flex items-center justify-between gap-3 mb-4 border border-neutral-700">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-lg transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{isSi ? 'ආපසු (Back)' : 'Back'}</span>
          </button>
          <span className="text-xs text-neutral-300 font-mono hidden sm:inline">
            {rfq.referenceNumber || rfq.id}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Direct Print */}
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-extrabold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg shadow-md transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{isSi ? 'මුද්‍රණය කරන්න (Print)' : 'Print Letterhead'}</span>
          </button>

          {/* Fallback direct save button */}
          <button
            type="button"
            onClick={handleDownloadHTML}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-lg shadow-md transition-all cursor-pointer"
            title="Download printable document file"
          >
            <Download className="w-4 h-4" />
            <span>{isSi ? 'PDF / File බාගත' : 'Save as File'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Official Printable Commercial Letterhead Document */}
      <div
        id="printable-quotation-view"
        className="w-full max-w-4xl bg-white text-black p-8 sm:p-12 shadow-2xl rounded-none sm:rounded-xl my-auto print:p-0 print:m-0 print:shadow-none print:w-full print:border-none"
        style={{ minHeight: '297mm' }}
      >
        {/* OFFICIAL LETTERHEAD HEADER (NO LOGOS) */}
        <div className="border-b-2 border-[#0B1F33] pb-6 flex flex-col sm:flex-row justify-between items-start gap-4">
          <div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-[#0B1F33] uppercase leading-none">
                {ownerSettings.businessName || 'Office Depot Lanka (Pvt) Ltd'}
              </h1>
              <span className="text-[10px] font-extrabold tracking-widest text-[#FF7A00] uppercase block mt-1">
                {ownerSettings.tagline || 'REQUEST. QUOTE. DELIVER.'}
              </span>
            </div>

            <div className="text-[10px] text-neutral-600 mt-3 leading-relaxed">
              <div>{ownerSettings.address || 'No. 88, Commercial Avenue, Colombo 03, Sri Lanka'}</div>
              <div>Hotline / WhatsApp: {ownerSettings.whatsappNumber || '+94 77 123 4567'} | Email: {ownerSettings.email || 'quotes@officedepot.lk'}</div>
              <div>
                Business Reg: {ownerSettings.companyRegistrationNo || 'PV-90481'}
                {ownerSettings.vatTinNumber && ` | VAT No: ${ownerSettings.vatTinNumber}`}
              </div>
            </div>
          </div>

          <div className="sm:text-right">
            <span className="inline-block bg-[#0B1F33] text-white font-extrabold text-xs px-3.5 py-1 rounded tracking-wider uppercase mb-2">
              COMMERCIAL QUOTATION
            </span>
            <div className="text-xs space-y-1">
              <div>
                <span className="text-neutral-500 font-medium">Quotation No:</span>{' '}
                <span className="font-mono font-bold text-neutral-900">{rfq.referenceNumber || rfq.id}</span>
              </div>
              <div>
                <span className="text-neutral-500 font-medium">Date:</span>{' '}
                <span className="font-mono font-semibold">{new Date(rfq.createdAt).toLocaleDateString()}</span>
              </div>
              <div>
                <span className="text-neutral-500 font-medium">Validity:</span>{' '}
                <span className="font-semibold">{validDays} Days from Date</span>
              </div>
            </div>
          </div>
        </div>

        {/* RECIPIENT & COMMERCIAL INFO */}
        <div className="grid grid-cols-2 gap-6 py-6 border-b border-neutral-300 text-xs">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
              QUOTED TO (CLIENT DETAILS):
            </span>
            <div className="font-bold text-sm text-neutral-900">{rfq.customer.name}</div>
            {rfq.customer.company && (
              <div className="font-semibold text-neutral-800">{rfq.customer.company}</div>
            )}
            <div className="text-neutral-600 mt-0.5">{rfq.customer.deliveryLocation}</div>
            <div className="text-neutral-600 font-mono mt-0.5">Phone: {rfq.customer.phone}</div>
            {rfq.customer.email && <div className="text-neutral-600">Email: {rfq.customer.email}</div>}
          </div>

          <div className="bg-neutral-50 p-3.5 rounded-lg border border-neutral-200 space-y-1.5 text-[11px]">
            <div>
              <span className="text-neutral-500">Prepared By:</span>{' '}
              <span className="font-semibold text-neutral-900">{ownerSettings.ownerName || 'Commercial Sales Division'}</span>
            </div>
            <div>
              <span className="text-neutral-500">Delivery Lead Time:</span>{' '}
              <span className="font-semibold text-neutral-900">{deliveryEstimate}</span>
            </div>
            <div>
              <span className="text-neutral-500">Payment Terms:</span>{' '}
              <span className="font-semibold text-neutral-900">{paymentTerms}</span>
            </div>
            {rfq.customer.urgency === 'urgent' && (
              <div className="text-red-600 font-bold">
                ⚡ Priority Order: Fast Track Delivery Approved
              </div>
            )}
          </div>
        </div>

        {/* LINE ITEMS TABLE */}
        <div className="py-6">
          <table className="w-full text-left text-xs border border-neutral-300 border-collapse">
            <thead>
              <tr className="bg-[#0B1F33] text-white font-bold text-[11px]">
                <th className="py-2.5 px-3 w-10 text-center border-r border-neutral-700">#</th>
                <th className="py-2.5 px-3 border-r border-neutral-700">Item Description & Specifications</th>
                <th className="py-2.5 px-3 w-20 text-center border-r border-neutral-700">Unit</th>
                <th className="py-2.5 px-3 w-20 text-right border-r border-neutral-700">Qty</th>
                <th className="py-2.5 px-3 w-28 text-right border-r border-neutral-700">Unit Price (LKR)</th>
                <th className="py-2.5 px-3 w-32 text-right">Total (LKR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-300">
              {rfq.items.map((item, idx) => {
                const unitP = item.quotedUnitPrice || item.targetBudget || 0;
                const lineTotal = item.quotedTotal || unitP * item.quantity;
                return (
                  <tr key={item.id} className={idx % 2 === 1 ? 'bg-neutral-50/80' : 'bg-white'}>
                    <td className="py-2.5 px-3 text-center text-neutral-500 font-mono border-r border-neutral-300">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 border-r border-neutral-300">
                      <div className="font-bold text-neutral-900">{item.name}</div>
                      {item.specs && (
                        <div className="text-[10px] text-neutral-600 mt-0.5">{item.specs}</div>
                      )}
                      {item.remarks && (
                        <div className="text-[10px] text-neutral-500 italic mt-0.5">Note: {item.remarks}</div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center text-neutral-700 border-r border-neutral-300">
                      {item.unit}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-neutral-900 border-r border-neutral-300">
                      {formatNumber(item.quantity)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-neutral-900 border-r border-neutral-300">
                      {formatNumber(unitP)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-950">
                      {formatNumber(lineTotal)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* FINANCIAL SUMMARY & WORDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-6 print-avoid-break">
          {/* Amount in words and Bank Info */}
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg">
              <span className="text-[10px] font-bold uppercase text-neutral-500 block mb-0.5">
                AMOUNT IN WORDS:
              </span>
              <span className="font-bold text-neutral-900 italic">
                {numberToWordsLKR(grandTotal)}
              </span>
            </div>

            <div className="text-[11px] text-neutral-600 space-y-1">
              <span className="font-bold text-neutral-800 block text-xs">
                Bank Remittance Details:
              </span>
              <div>Account Name: {ownerSettings.bankAccountName || 'Office Depot Lanka (Pvt) Ltd'}</div>
              <div>
                Bank: {ownerSettings.bankName || 'Commercial Bank of Ceylon PLC'}
                {ownerSettings.bankBranch && ` | Branch: ${ownerSettings.bankBranch}`}
              </div>
              <div>Account No: {ownerSettings.bankAccountNumber || '1000 4829 1002'}</div>
              {ownerSettings.bankSwiftCode && (
                <div>SWIFT / Clearing: {ownerSettings.bankSwiftCode}</div>
              )}
            </div>
          </div>

          {/* Totals Table */}
          <div className="bg-neutral-50 border border-neutral-300 rounded-lg p-4 space-y-2 text-xs">
            <div className="flex justify-between text-neutral-700">
              <span>Subtotal:</span>
              <span className="font-mono font-semibold text-neutral-900">
                {formatCurrency(subtotal)}
              </span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-neutral-700">
                <span>Discount ({pricing?.discountPercent}%):</span>
                <span className="font-mono text-neutral-800">
                  - {formatCurrency(discountAmount)}
                </span>
              </div>
            )}

            {deliveryFee > 0 && (
              <div className="flex justify-between text-neutral-700">
                <span>Delivery & Handling:</span>
                <span className="font-mono text-neutral-800">
                  + {formatCurrency(deliveryFee)}
                </span>
              </div>
            )}

            <div className="pt-2 border-t-2 border-[#0B1F33] flex justify-between items-baseline">
              <span className="text-sm font-black text-[#0B1F33] uppercase">
                GRAND TOTAL:
              </span>
              <span className="text-lg font-black font-mono text-[#0B1F33]">
                {formatCurrency(grandTotal)}
              </span>
            </div>
          </div>
        </div>

        {/* COMMERCIAL TERMS & CONDITIONS */}
        <div className="border-t border-neutral-300 pt-4 pb-8 text-[10px] text-neutral-600 space-y-1 print-avoid-break">
          <span className="font-bold uppercase tracking-wider text-neutral-800 block text-xs mb-1">
            Standard Commercial Terms:
          </span>
          {ownerSettings.customTermsAndConditions && ownerSettings.customTermsAndConditions.trim() ? (
            <div className="whitespace-pre-line leading-relaxed">
              {ownerSettings.customTermsAndConditions}
            </div>
          ) : (
            <>
              <div>1. Quotation is valid for {validDays} days from the date of issue. Prices subject to change after validity period.</div>
              <div>2. Delivery will be executed within {deliveryEstimate} upon receipt of official Purchase Order (PO).</div>
              <div>3. Payment terms as agreed: {paymentTerms}. Cheques should be drawn in favor of '{ownerSettings.bankAccountName || ownerSettings.businessName || 'Office Depot Lanka (Pvt) Ltd'}'.</div>
              <div>4. All items supplied are genuine, certified brand originals with manufacturer standard warranty.</div>
            </>
          )}
        </div>

        {/* SIGNATURE BLOCKS */}
        <div className="grid grid-cols-2 gap-12 pt-8 border-t-2 border-neutral-400 text-xs print-avoid-break">
          <div>
            <div className="h-14 border-b border-dashed border-neutral-400 w-52 mb-1" />
            <div className="font-bold text-neutral-900">Authorized Signature & Seal</div>
            <div className="text-[11px] text-neutral-600">{ownerSettings.businessName || 'Office Depot Lanka (Pvt) Ltd'}</div>
          </div>

          <div className="text-right">
            <div className="h-14 border-b border-dashed border-neutral-400 w-52 ml-auto mb-1" />
            <div className="font-bold text-neutral-900">Client Acceptance & Signature</div>
            <div className="text-[11px] text-neutral-600">Name / Designation & Date</div>
          </div>
        </div>
      </div>
    </div>
  );
};
