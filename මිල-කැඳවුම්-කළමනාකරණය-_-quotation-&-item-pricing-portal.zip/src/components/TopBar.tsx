import React from 'react';
import { FileSpreadsheet, Plus, Settings, Inbox, BookOpen, Globe, Lock, LogOut, Search, ShieldCheck } from 'lucide-react';
import { Language } from '../types';

interface TopBarProps {
  currentTab: 'customer' | 'admin' | 'sheets' | 'settings';
  setCurrentTab: (tab: 'customer' | 'admin' | 'sheets' | 'settings') => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  receivedCount: number;
  isAdminAuthenticated: boolean;
  onOpenAdminLogin: () => void;
  onAdminLogout: () => void;
  onOpenTrackModal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentTab,
  setCurrentTab,
  language,
  setLanguage,
  receivedCount,
  isAdminAuthenticated,
  onOpenAdminLogin,
  onAdminLogout,
  onOpenTrackModal,
}) => {
  const isSi = language === 'si';

  return (
    <header className="sticky top-0 z-40 bg-[#0B1F33] border-b border-neutral-800 text-white shadow-md no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          {/* Zone 1: Brand Wordmark (No Logo) */}
          <div
            className="flex items-center gap-2 shrink-0 cursor-pointer"
            onClick={() => setCurrentTab('customer')}
          >
            <div>
              <span className="text-base sm:text-lg font-black tracking-tight text-white whitespace-nowrap block leading-tight">
                OFFICE DEPOT
              </span>
              <span className="text-[10px] tracking-widest text-[#FF7A00] font-bold block uppercase">
                REQUEST. QUOTE. DELIVER.
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-semibold text-neutral-300">
            {/* PUBLIC NAVIGATION (Always visible to all customers) */}
            <button
              type="button"
              onClick={() => setCurrentTab('customer')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentTab === 'customer'
                  ? 'bg-white/10 text-white font-bold'
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-[#00A6A6]" />
              <span>{isSi ? 'මිල කැඳවීමක් ඉල්ලුම් කරන්න' : 'Request Quotation'}</span>
            </button>

            <button
              type="button"
              onClick={onOpenTrackModal}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors text-neutral-300 hover:text-white hover:bg-white/5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-[#FF7A00]" />
              <span>{isSi ? 'තත්වය පරීක්ෂා කරන්න (Track)' : 'Track Quote'}</span>
            </button>

            {/* UNLOCKED ADMIN TABS (ONLY VISIBLE ONCE LOGGED IN AS ADMIN) */}
            {isAdminAuthenticated && (
              <>
                <span className="text-neutral-600 px-1">|</span>

                <button
                  type="button"
                  onClick={() => setCurrentTab('admin')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    currentTab === 'admin'
                      ? 'bg-white/10 text-white font-bold'
                      : 'hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Inbox className="w-3.5 h-3.5 text-[#00A6A6]" />
                  <span>{isSi ? 'ඉල්ලුම්පත් කළමනාකරණය' : 'Quotation Requests'}</span>
                  {receivedCount > 0 && (
                    <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-[#00A6A6] text-neutral-950 font-bold font-mono-numbers">
                      {receivedCount}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentTab('sheets')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    currentTab === 'sheets'
                      ? 'bg-white/10 text-white font-bold'
                      : 'hover:text-white hover:bg-white/5'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Google Sheets Sync</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentTab('settings')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    currentTab === 'settings'
                      ? 'bg-white/10 text-white font-bold'
                      : 'hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Settings className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{isSi ? 'සැකසුම්' : 'Settings'}</span>
                </button>
              </>
            )}
          </nav>

          {/* Zone 3: Language Switcher & Admin Access Button */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Language Toggle (සිංහල / English) */}
            <button
              type="button"
              onClick={() => setLanguage(isSi ? 'en' : 'si')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-white/5 hover:bg-white/10 border border-neutral-700 rounded-lg transition-colors cursor-pointer"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#00A6A6]" />
              <span>{isSi ? 'English' : 'සිංහල'}</span>
            </button>

            {/* Admin Entry Control: Discreet Lock button when logged out; Status + Logout when logged in */}
            {!isAdminAuthenticated ? (
              <button
                type="button"
                onClick={onOpenAdminLogin}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-white/5 hover:bg-white/10 border border-neutral-700 rounded-lg transition-colors cursor-pointer"
                title="Admin Passcode Login"
              >
                <Lock className="w-3.5 h-3.5 text-[#FF7A00]" />
                <span className="hidden sm:inline">Admin Login</span>
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setCurrentTab('admin')}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-[#00A6A6] bg-[#00A6A6]/10 border border-[#00A6A6]/30 rounded-lg cursor-pointer"
                  title="Admin Dashboard"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Admin</span>
                </button>

                <button
                  type="button"
                  onClick={onAdminLogout}
                  className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-950/40 border border-red-500/30 rounded-lg transition-colors cursor-pointer"
                  title="Admin Logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Primary Orange CTA */}
            <button
              type="button"
              onClick={() => setCurrentTab('customer')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-extrabold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isSi ? 'නව මිල කැඳවුමක්' : '+ New RFQ'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-between border-t border-neutral-800 py-2 overflow-x-auto text-xs">
          <button
            type="button"
            onClick={() => setCurrentTab('customer')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${currentTab === 'customer' ? 'bg-white/10 font-bold text-[#00A6A6]' : 'text-neutral-400'}`}
          >
            {isSi ? 'භාණ්ඩ ඉල්ලුම් කිරීම' : 'Request Quote'}
          </button>

          <button
            type="button"
            onClick={onOpenTrackModal}
            className="px-3 py-1.5 rounded-md whitespace-nowrap text-[#FF7A00] font-semibold"
          >
            {isSi ? 'Track' : 'Track'}
          </button>

          {isAdminAuthenticated && (
            <>
              <button
                type="button"
                onClick={() => setCurrentTab('admin')}
                className={`px-3 py-1.5 rounded-md whitespace-nowrap ${currentTab === 'admin' ? 'bg-white/10 font-bold text-white' : 'text-neutral-400'}`}
              >
                Admin ({receivedCount})
              </button>

              <button
                type="button"
                onClick={() => setCurrentTab('sheets')}
                className={`px-3 py-1.5 rounded-md whitespace-nowrap ${currentTab === 'sheets' ? 'bg-white/10 font-bold text-[#00A6A6]' : 'text-neutral-400'}`}
              >
                Sheets
              </button>
            </>
          )}

          {!isAdminAuthenticated && (
            <button
              type="button"
              onClick={onOpenAdminLogin}
              className="px-3 py-1.5 rounded-md whitespace-nowrap text-neutral-400 flex items-center gap-1"
            >
              <Lock className="w-3 h-3 text-[#FF7A00]" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
