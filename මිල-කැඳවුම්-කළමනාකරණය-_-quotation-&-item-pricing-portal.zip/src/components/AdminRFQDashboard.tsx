import React, { useState } from 'react';
import {
  Search,
  Filter,
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  ExternalLink,
  Eye,
  Trash2,
  MessageSquare,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
  RefreshCw,
  Plus,
  Zap,
  Phone,
  Building,
  User,
  MapPin,
  Paperclip,
  LogOut,
  ShieldCheck,
  Send,
  Printer
} from 'lucide-react';
import { RFQRequest, RFQStatus, Language, OwnerSettings } from '../types';
import {
  formatCurrency,
  formatNumber,
  copyRFQToGoogleSheets,
  copyAllRFQsToGoogleSheets,
  downloadRFQCSV,
  downloadAllRFQsCSV,
} from '../utils/exportUtils';

interface AdminRFQDashboardProps {
  rfqs: RFQRequest[];
  language: Language;
  ownerSettings: OwnerSettings;
  onViewRFQ: (rfq: RFQRequest) => void;
  onOpenPrintView?: (rfq: RFQRequest) => void;
  onUpdateStatus: (id: string, status: RFQStatus) => void;
  onDeleteRFQ: (id: string) => void;
  onRefresh: () => void;
  onOpenCustomerForm: () => void;
  onOpenSheetsGuide: () => void;
  onAdminLogout: () => void;
}

export const AdminRFQDashboard: React.FC<AdminRFQDashboardProps> = ({
  rfqs,
  language,
  ownerSettings,
  onViewRFQ,
  onOpenPrintView,
  onUpdateStatus,
  onDeleteRFQ,
  onRefresh,
  onOpenCustomerForm,
  onOpenSheetsGuide,
  onAdminLogout,
}) => {
  const isSi = language === 'si';

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [copiedFormula, setCopiedFormula] = useState(false);

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com';
  const importDataFormula = `=IMPORTDATA("${currentOrigin}/api/rfq/export/all.csv")`;

  const filteredRfqs = rfqs.filter((r) => {
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    if (!matchesStatus) return false;

    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    const matchId = (r.referenceNumber || r.id).toLowerCase().includes(term);
    const matchCust = (r.customer.name || '').toLowerCase().includes(term);
    const matchComp = (r.customer.company || '').toLowerCase().includes(term);
    const matchPhone = (r.customer.phone || '').toLowerCase().includes(term);
    const matchLoc = (r.customer.deliveryLocation || '').toLowerCase().includes(term);
    const matchItem = r.items.some((i) => i.name.toLowerCase().includes(term));

    return matchId || matchCust || matchComp || matchPhone || matchLoc || matchItem;
  });

  const totalRequests = rfqs.length;
  const newRequestsCount = rfqs.filter((r) => r.status === 'new').length;
  const urgentCount = rfqs.filter((r) => r.customer.urgency === 'urgent').length;
  const quotedCount = rfqs.filter((r) => r.status === 'quoted' || r.status === 'completed').length;

  const handleCopySingle = async (r: RFQRequest) => {
    const success = await copyRFQToGoogleSheets(r);
    if (success) {
      setCopiedId(r.id);
      setTimeout(() => setCopiedId(null), 2500);
    }
  };

  const handleCopyAll = async () => {
    const success = await copyAllRFQsToGoogleSheets(rfqs);
    if (success) {
      setCopiedAll(true);
      setTimeout(() => setCopiedAll(false), 2500);
    }
  };

  const handleCopyFormula = async () => {
    await navigator.clipboard.writeText(importDataFormula);
    setCopiedFormula(true);
    setTimeout(() => setCopiedFormula(false), 2500);
  };

  const getStatusBadge = (status: RFQStatus) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/30 font-bold">
            <AlertCircle className="w-3 h-3" />
            <span>{isSi ? 'නව (New)' : 'New'}</span>
          </span>
        );
      case 'quoted':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-[#00A6A6]/10 text-[#00A6A6] border border-[#00A6A6]/40 font-bold">
            <CheckCircle2 className="w-3 h-3" />
            <span>{isSi ? 'මිල යැව්වා (Quoted)' : 'Quoted'}</span>
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
            <CheckCircle2 className="w-3 h-3" />
            <span>{isSi ? 'තහවුරු විය (Closed)' : 'Completed'}</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-neutral-800 text-neutral-400 font-medium">
            <XCircle className="w-3 h-3" />
            <span>{isSi ? 'අවලංගුයි' : 'Cancelled'}</span>
          </span>
        );
      default:
        return <span>{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Binance style Deep Navy #0B1F33 */}
      <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-[#00A6A6]/20 text-[#00A6A6] border border-[#00A6A6]/40 uppercase tracking-wider">
                ADMIN ACCESS VERIFIED
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
              {isSi ? 'පාරිභෝගික මිල කැඳවුම් පාලක පුවරුව' : 'Admin Quotations Hub'}
            </h1>
            <p className="text-xs text-neutral-300 mt-0.5">
              {isSi
                ? 'පාරිභෝගිකයින් වෙබ් පිටුව හරහා එවූ සියලුම භාණ්ඩ ඉල්ලුම්පත් සහ Upload කළ ලිපිගොනු මෙහි ඇත. අපගේ මිල ගණන් පිරවීම සහ පාරිභෝගිකයාට යැවීම මෙතැනින් සිදු කරන්න.'
                : 'Review customer bills of materials, set unit prices, and dispatch formal quotation proposals.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onRefresh}
              className="p-2 text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onOpenCustomerForm}
              className="px-3 py-2 text-xs font-bold text-neutral-900 bg-white hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
            >
              <span>{isSi ? 'Customer Form එක' : 'View Public Form'}</span>
            </button>

            {/* Admin Logout */}
            <button
              type="button"
              onClick={onAdminLogout}
              className="p-2 text-red-400 hover:text-red-300 hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer"
              title="Logout from Admin"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 KPIs with sharp Binance typography */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
          <div className="p-4 bg-[#071524] rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-400 uppercase tracking-wider block">
              {isSi ? 'මුළු ඉල්ලුම්පත් ගණන' : 'Total Requests'}
            </span>
            <span className="text-2xl font-extrabold font-mono-numbers text-white mt-1 block">
              {totalRequests}
            </span>
          </div>

          <div className="p-4 bg-[#071524] rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-400 uppercase tracking-wider block">
              {isSi ? 'මිල යැවිය යුතු (New)' : 'New Pending Pricing'}
            </span>
            <span className="text-2xl font-extrabold font-mono-numbers text-[#FF7A00] mt-1 block">
              {newRequestsCount}
            </span>
          </div>

          <div className="p-4 bg-[#071524] rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-400 uppercase tracking-wider block">
              {isSi ? 'කඩිනම් ඉල්ලුම්පත් (Urgent)' : 'Urgent Requests'}
            </span>
            <span className="text-2xl font-extrabold font-mono-numbers text-red-400 mt-1 block">
              {urgentCount}
            </span>
          </div>

          <div className="p-4 bg-[#071524] rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-400 uppercase tracking-wider block">
              {isSi ? 'මිල යැවූ (Quoted)' : 'Quoted Proposals'}
            </span>
            <span className="text-2xl font-extrabold font-mono-numbers text-[#00A6A6] mt-1 block">
              {quotedCount}
            </span>
          </div>
        </div>
      </div>

      {/* GOOGLE SHEETS TOOLBAR */}
      <div className="bg-[#0B1F33] border border-neutral-800 text-white rounded-2xl p-5 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00A6A6]/20 border border-[#00A6A6] text-[#00A6A6] flex items-center justify-center font-bold shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {isSi ? 'Google Sheets Admin සමමුහුර්තකරණය (Sync Master)' : 'Google Sheets Master Admin Sync'}
              </h3>
              <p className="text-xs text-neutral-400">
                {isSi
                  ? 'සියලුම පාරිභෝගික ඉල්ලුම්පත් සහ මිල ගණන් ඔබගේ Google Sheet එකේ එකතු කරගන්න.'
                  : 'Stream or copy all customer bids and quoted pricing into Google Sheets.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleCopyAll}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-neutral-950 bg-[#00A6A6] hover:bg-[#12b5b5] rounded-lg transition-colors cursor-pointer"
            >
              {copiedAll ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedAll ? 'Copied!' : (isSi ? 'සියල්ල Sheets සඳහා Copy' : 'Copy All for Sheets')}</span>
            </button>

            <a
              href="https://sheets.new"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              <ExternalLink className="w-4 h-4 text-[#00A6A6]" />
              <span>{isSi ? 'sheets.new අරින්න' : 'Launch sheets.new'}</span>
            </a>

            <button
              type="button"
              onClick={() => downloadAllRFQsCSV(rfqs)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV</span>
            </button>
          </div>
        </div>

        {/* Formula bar */}
        <div className="bg-[#071524] p-2.5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs border border-neutral-800">
          <div className="flex items-center gap-2 truncate">
            <Zap className="w-3.5 h-3.5 text-[#FF7A00] shrink-0" />
            <code className="text-[#00A6A6] font-mono text-[11px] truncate">
              {importDataFormula}
            </code>
          </div>
          <button
            type="button"
            onClick={handleCopyFormula}
            className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 rounded text-neutral-200 text-[11px] font-semibold shrink-0 cursor-pointer"
          >
            {copiedFormula ? 'Copied!' : 'Copy Formula'}
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-neutral-200 rounded-xl p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder={isSi ? 'Reference ID, පාරිභෝගිකයා, දුරකථනය හෝ භාණ්ඩය සොයන්න...' : 'Search by Ref ID, customer, phone, or item...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-300 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#00A6A6]"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg overflow-x-auto text-xs">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'all' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              All ({rfqs.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('new')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'new' ? 'bg-white text-amber-700 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              New ({newRequestsCount})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('quoted')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'quoted' ? 'bg-white text-[#00A6A6] shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Quoted ({quotedCount})
            </button>
          </div>
        </div>
      </div>

      {/* Quotation Requests Master Table */}
      <div className="bg-white border border-neutral-200 rounded-xl shadow-xs overflow-hidden">
        {filteredRfqs.length === 0 ? (
          <div className="text-center py-12 px-4">
            <FileText className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-neutral-800">
              {isSi ? 'ඉල්ලුම්පත් කිසිවක් හමු නොවීය' : 'No Quotation Requests Found'}
            </h3>
            <p className="text-xs text-neutral-500 mt-1">
              {isSi ? 'පාරිභෝගිකයින් එවූ පසු ඒවා මෙහි පෙන්නුම් කෙරේ.' : 'Customer submissions will appear here in real time.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#0B1F33] text-white font-semibold">
                  <th className="py-3 px-3 w-32">Ref ID & {isSi ? 'දිනය' : 'Date'}</th>
                  <th className="py-3 px-3 min-w-[200px]">{isSi ? 'පාරිභෝගිකයා සහ සම්බන්ධතා' : 'Customer & Contact'}</th>
                  <th className="py-3 px-3 min-w-[220px]">{isSi ? 'අවශ්‍ය භාණ්ඩ සහ Files' : 'Requested Items & Files'}</th>
                  <th className="py-3 px-3 w-28 text-right">{isSi ? 'අපේ මිල කැඳවීම' : 'Our Quoted Total'}</th>
                  <th className="py-3 px-3 w-28">{isSi ? 'තත්වය' : 'Status'}</th>
                  <th className="py-3 px-3 text-right min-w-[220px]">{isSi ? 'මිල යැවීම සහ ක්‍රියා' : 'Quote & Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {filteredRfqs.map((r) => (
                  <tr key={r.id} className="hover:bg-neutral-50/80 transition-colors">
                    {/* Reference ID and Date */}
                    <td className="py-3 px-3">
                      <span className="font-mono font-extrabold text-[#0B1F33] block">
                        {r.referenceNumber || r.id}
                      </span>
                      <span className="text-[11px] text-neutral-400 block font-mono-numbers">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </span>
                    </td>

                    {/* Customer */}
                    <td className="py-3 px-3">
                      <div className="font-bold text-neutral-900">
                        {r.customer.name}
                      </div>
                      {r.customer.company && (
                        <div className="text-[11px] text-[#FF7A00] font-semibold">
                          {r.customer.company}
                        </div>
                      )}
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[11px] font-mono-numbers text-neutral-600">
                          {r.customer.phone}
                        </span>
                        <a
                          href={`https://wa.me/${r.customer.phone.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          title="WhatsApp Customer"
                          className="text-green-600 hover:text-green-700"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </a>
                      </div>
                      {r.customer.deliveryLocation && (
                        <div className="flex items-center gap-1 text-[11px] text-neutral-500 mt-0.5">
                          <MapPin className="w-3 h-3 text-neutral-400 shrink-0" />
                          <span className="truncate max-w-[160px]">{r.customer.deliveryLocation}</span>
                        </div>
                      )}
                    </td>

                    {/* Items & Attachments */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="font-bold text-[#00A6A6] font-mono-numbers bg-[#00A6A6]/10 px-1.5 py-0.5 rounded border border-[#00A6A6]/30">
                          {r.items.length} {isSi ? 'භාණ්ඩ' : 'items'}
                        </span>
                        {r.attachments && r.attachments.length > 0 && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded border border-purple-200">
                            <Paperclip className="w-3 h-3" />
                            <span>{r.attachments.length} files</span>
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-neutral-700 font-medium truncate max-w-[220px] block">
                        {r.items.map((i) => `${i.name} (${i.quantity} ${i.unit})`).slice(0, 2).join(', ')}
                        {r.items.length > 2 ? '...' : ''}
                      </span>
                    </td>

                    {/* Our Quoted Total */}
                    <td className="py-3 px-3 text-right">
                      {r.pricing ? (
                        <span className="font-mono-numbers font-bold text-emerald-700 text-sm block">
                          රු. {formatNumber(r.pricing.grandTotal)}
                        </span>
                      ) : r.ourQuotedTotal ? (
                        <span className="font-mono-numbers font-bold text-emerald-700 text-sm block">
                          රු. {formatNumber(r.ourQuotedTotal)}
                        </span>
                      ) : (
                        <span className="text-[11px] text-neutral-400 italic">
                          {isSi ? 'මිල නියම කර නැත' : 'Not priced yet'}
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-3">
                      <div className="space-y-1">
                        {getStatusBadge(r.status)}
                        <select
                          value={r.status}
                          onChange={(e) => onUpdateStatus(r.id, e.target.value as RFQStatus)}
                          className="block w-full text-[11px] bg-neutral-50 border border-neutral-300 rounded px-1.5 py-0.5 text-neutral-700 focus:bg-white"
                        >
                          <option value="new">New</option>
                          <option value="quoted">Quoted</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </td>

                    {/* ACTIONS: PRICE & SEND QUOTE TO CUSTOMER */}
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* MAIN PRIMARY ACTION: OPEN QUOTE PROPOSAL GENERATOR */}
                        <button
                          type="button"
                          onClick={() => onViewRFQ(r)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-950 bg-[#FF7A00] hover:bg-[#FFA142] rounded-lg shadow-xs transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{isSi ? 'මිල යවන්න' : 'Price & Quote'}</span>
                        </button>

                        {/* Print PDF directly */}
                        {onOpenPrintView && (
                          <button
                            type="button"
                            onClick={() => onOpenPrintView(r)}
                            title={isSi ? 'නිල Quotation PDF මුද්‍රණය' : 'Print Official PDF Letterhead'}
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition-colors cursor-pointer"
                          >
                            <Printer className="w-4 h-4 text-[#00A6A6]" />
                          </button>
                        )}

                        {/* Copy for Google Sheets */}
                        <button
                          type="button"
                          onClick={() => handleCopySingle(r)}
                          title="Copy for Google Sheets"
                          className={`p-1.5 rounded transition-colors cursor-pointer ${
                            copiedId === r.id
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'text-neutral-500 hover:text-[#00A6A6] hover:bg-neutral-100'
                          }`}
                        >
                          {copiedId === r.id ? <Check className="w-4 h-4 text-emerald-700" /> : <Copy className="w-4 h-4" />}
                        </button>

                        {/* Download CSV */}
                        <button
                          type="button"
                          onClick={() => downloadRFQCSV(r)}
                          title="Download CSV"
                          className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded cursor-pointer"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* Delete */}
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(isSi ? 'මෙම ඉල්ලුම්පත මකා දැමීමට අවශ්‍යද?' : 'Are you sure you want to delete this RFQ?')) {
                              onDeleteRFQ(r.id);
                            }
                          }}
                          title="Delete"
                          className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
