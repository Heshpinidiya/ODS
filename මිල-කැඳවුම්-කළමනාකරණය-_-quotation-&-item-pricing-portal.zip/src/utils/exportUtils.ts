import { RFQRequest, OwnerSettings } from '../types';

export function formatNumber(val: number): string {
  return new Intl.NumberFormat('en-US').format(val || 0);
}

export function formatCurrency(amount: number, currency = 'LKR'): string {
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount || 0);

  if (currency === 'LKR' || currency === 'රු.') {
    return `රු. ${formatted}`;
  }
  return `${currency} ${formatted}`;
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

/**
 * Generates TSV for a single RFQ request (including quoted prices) for Google Sheets
 */
export function generateRFQTSV(rfq: RFQRequest): string {
  const lines: string[] = [];

  lines.push(`Reference ID:\t${rfq.referenceNumber || rfq.id}`);
  lines.push(`Date:\t${new Date(rfq.createdAt).toLocaleString()}`);
  lines.push(`Customer:\t${rfq.customer.name}`);
  lines.push(`Company:\t${rfq.customer.company || '-'}`);
  lines.push(`Phone:\t${rfq.customer.phone}`);
  lines.push(`Location:\t${rfq.customer.deliveryLocation}`);
  lines.push(`Urgency:\t${rfq.customer.urgency.toUpperCase()}`);
  lines.push(`Status:\t${rfq.status.toUpperCase()}`);
  if (rfq.pricing) {
    lines.push(`Quoted Total:\t${rfq.pricing.grandTotal}`);
  }
  lines.push('');

  lines.push([
    '#',
    'Item Name',
    'Specifications',
    'Quantity',
    'Unit',
    'Customer Budget',
    'Quoted Unit Price',
    'Quoted Total',
    'Remarks'
  ].join('\t'));

  rfq.items.forEach((item, idx) => {
    lines.push([
      (idx + 1).toString(),
      item.name || '',
      item.specs || '',
      item.quantity.toString(),
      item.unit || '',
      item.targetBudget ? item.targetBudget.toString() : '-',
      item.quotedUnitPrice ? item.quotedUnitPrice.toString() : '-',
      item.quotedTotal ? item.quotedTotal.toString() : '-',
      item.remarks || ''
    ].join('\t'));
  });

  if (rfq.pricing) {
    lines.push('');
    lines.push(`\t\t\t\t\tSubtotal:\t${rfq.pricing.subtotal}`);
    if (rfq.pricing.discountAmount > 0) {
      lines.push(`\t\t\t\t\tDiscount (${rfq.pricing.discountPercent}%):\t-${rfq.pricing.discountAmount}`);
    }
    if (rfq.pricing.deliveryFee > 0) {
      lines.push(`\t\t\t\t\tDelivery Fee:\t+${rfq.pricing.deliveryFee}`);
    }
    lines.push(`\t\t\t\t\tGRAND TOTAL:\t${rfq.pricing.grandTotal}`);
  }

  return lines.join('\n');
}

export async function copyRFQToGoogleSheets(rfq: RFQRequest): Promise<boolean> {
  try {
    const tsv = generateRFQTSV(rfq);
    await navigator.clipboard.writeText(tsv);
    return true;
  } catch (err) {
    console.error('Failed to copy to clipboard:', err);
    return false;
  }
}

export async function copyAllRFQsToGoogleSheets(rfqs: RFQRequest[]): Promise<boolean> {
  try {
    const lines: string[] = [];
    lines.push([
      'Reference ID',
      'Date & Time',
      'Customer Name',
      'Company',
      'Phone (WhatsApp)',
      'Delivery Location',
      'Urgency',
      'Item #',
      'Item Name',
      'Specifications',
      'Quantity',
      'Unit',
      'Customer Budget',
      'Quoted Unit Price',
      'Quoted Total',
      'Status',
      'Quoted Grand Total'
    ].join('\t'));

    rfqs.forEach((r) => {
      const dateStr = new Date(r.createdAt).toLocaleString();
      const grandTotal = r.pricing ? r.pricing.grandTotal : (r.ourQuotedTotal || '');
      r.items.forEach((item, idx) => {
        lines.push([
          r.referenceNumber || r.id,
          dateStr,
          r.customer.name,
          r.customer.company || '',
          r.customer.phone,
          r.customer.deliveryLocation,
          r.customer.urgency,
          (idx + 1).toString(),
          item.name,
          item.specs || '',
          item.quantity.toString(),
          item.unit,
          item.targetBudget ? item.targetBudget.toString() : '',
          item.quotedUnitPrice ? item.quotedUnitPrice.toString() : '',
          item.quotedTotal ? item.quotedTotal.toString() : '',
          r.status,
          grandTotal.toString()
        ].join('\t'));
      });
    });

    await navigator.clipboard.writeText(lines.join('\n'));
    return true;
  } catch (err) {
    console.error('Failed to copy all to clipboard:', err);
    return false;
  }
}

export function downloadRFQCSV(rfq: RFQRequest): void {
  let csv = '\uFEFF';
  csv += `"Reference ID","${rfq.referenceNumber || rfq.id}"\r\n`;
  csv += `"Date","${new Date(rfq.createdAt).toLocaleString()}"\r\n`;
  csv += `"Customer","${(rfq.customer.name || '').replace(/"/g, '""')}"\r\n`;
  csv += `"Company","${(rfq.customer.company || '').replace(/"/g, '""')}"\r\n`;
  csv += `"Phone","${rfq.customer.phone || ''}"\r\n`;
  csv += `"Delivery Location","${(rfq.customer.deliveryLocation || '').replace(/"/g, '""')}"\r\n`;
  csv += `"Status","${rfq.status}"\r\n\r\n`;

  csv += `"Item #","Item Name","Specifications","Quantity","Unit","Customer Budget","Quoted Unit Price","Quoted Total"\r\n`;

  rfq.items.forEach((item, idx) => {
    const cleanName = (item.name || '').replace(/"/g, '""');
    const cleanSpecs = (item.specs || '').replace(/"/g, '""');
    const cleanUnit = (item.unit || '').replace(/"/g, '""');
    const cleanBudget = item.targetBudget ? item.targetBudget : '';
    const quotedUnitPrice = item.quotedUnitPrice ? item.quotedUnitPrice : '';
    const quotedTotal = item.quotedTotal ? item.quotedTotal : '';

    csv += `"${idx + 1}","${cleanName}","${cleanSpecs}",${item.quantity},"${cleanUnit}","${cleanBudget}","${quotedUnitPrice}","${quotedTotal}"\r\n`;
  });

  if (rfq.pricing) {
    csv += `\r\n,,,,"Subtotal",,"${rfq.pricing.subtotal}"\r\n`;
    if (rfq.pricing.discountAmount > 0) {
      csv += `,,,,"Discount (${rfq.pricing.discountPercent}%)",,"-${rfq.pricing.discountAmount}"\r\n`;
    }
    if (rfq.pricing.deliveryFee > 0) {
      csv += `,,,,"Delivery Fee",,"${rfq.pricing.deliveryFee}"\r\n`;
    }
    csv += `,,,,"GRAND TOTAL",,"${rfq.pricing.grandTotal}"\r\n`;
  }

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${rfq.referenceNumber || rfq.id}_quotation.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function downloadAllRFQsCSV(rfqs: RFQRequest[]): void {
  let csv = '\uFEFF';
  csv += `"Reference ID","Date & Time","Customer Name","Company","Phone","Location","Urgency","Item #","Item Name","Specifications","Quantity","Unit","Target Budget","Quoted Unit Price","Quoted Total","Status","Grand Quoted Total"\r\n`;

  rfqs.forEach((r) => {
    const dateStr = new Date(r.createdAt).toLocaleString();
    const custName = (r.customer?.name || '').replace(/"/g, '""');
    const custCompany = (r.customer?.company || '').replace(/"/g, '""');
    const custPhone = (r.customer?.phone || '').replace(/"/g, '""');
    const custLoc = (r.customer?.deliveryLocation || '').replace(/"/g, '""');
    const custUrg = r.customer?.urgency || 'normal';
    const grandQuoted = r.pricing ? r.pricing.grandTotal : (r.ourQuotedTotal || '');

    r.items.forEach((item, idx) => {
      const cleanName = (item.name || '').replace(/"/g, '""');
      const cleanSpecs = (item.specs || '').replace(/"/g, '""');
      const cleanUnit = (item.unit || '').replace(/"/g, '""');
      const cleanBudget = item.targetBudget ? item.targetBudget : '';
      const quotedUnitPrice = item.quotedUnitPrice ? item.quotedUnitPrice : '';
      const quotedTotal = item.quotedTotal ? item.quotedTotal : '';

      csv += `"${r.referenceNumber || r.id}","${dateStr}","${custName}","${custCompany}","${custPhone}","${custLoc}","${custUrg}","${idx + 1}","${cleanName}","${cleanSpecs}",${item.quantity},"${cleanUnit}","${cleanBudget}","${quotedUnitPrice}","${quotedTotal}","${r.status}","${grandQuoted}"\r\n`;
    });
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `office_depot_quotations_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Message sent by Customer to Office Depot Owner
 */
export function generateCustomerWhatsAppUrl(rfq: RFQRequest, ownerPhone = ''): string {
  const lines: string[] = [];
  lines.push(`🔔 *OFFICE DEPOT - NEW QUOTATION REQUEST*`);
  lines.push(`*Ref ID:* ${rfq.referenceNumber || rfq.id}`);
  lines.push(`*Date:* ${new Date(rfq.createdAt).toLocaleDateString()}`);
  lines.push(`*Customer:* ${rfq.customer.name} ${rfq.customer.company ? '(' + rfq.customer.company + ')' : ''}`);
  lines.push(`*Phone:* ${rfq.customer.phone}`);
  if (rfq.customer.deliveryLocation) lines.push(`*Delivery Location:* ${rfq.customer.deliveryLocation}`);
  if (rfq.customer.urgency === 'urgent') lines.push(`⚡ *URGENCY: URGENT (Within 24-48 Hours)*`);
  if (rfq.customer.requiredDate) lines.push(`📅 *Required By:* ${rfq.customer.requiredDate}`);
  lines.push(``);
  lines.push(`📦 *Requested Items (${rfq.items.length}):*`);

  rfq.items.forEach((item, index) => {
    let itemLine = `${index + 1}. *${item.name}* - ${item.quantity} ${item.unit}`;
    if (item.specs) itemLine += `\n   ↳ Specs: ${item.specs}`;
    if (item.targetBudget) itemLine += `\n   ↳ Target Budget: රු. ${formatNumber(item.targetBudget)}`;
    lines.push(itemLine);
  });

  if (rfq.attachments && rfq.attachments.length > 0) {
    lines.push(``);
    lines.push(`📎 *Uploaded Files (${rfq.attachments.length}):*`);
    rfq.attachments.forEach((att) => {
      lines.push(`• ${att.name} (${formatFileSize(att.size)})`);
    });
  }

  if (rfq.customer.notes) {
    lines.push(``);
    lines.push(`📝 *Notes:* ${rfq.customer.notes}`);
  }

  lines.push(``);
  lines.push(`_Please review and provide your best quotation. Thank you!_`);

  const encodedText = encodeURIComponent(lines.join('\n'));
  const cleanPhone = ownerPhone.replace(/\D/g, '');
  return cleanPhone ? `https://wa.me/${cleanPhone}?text=${encodedText}` : `https://wa.me/?text=${encodedText}`;
}

/**
 * Message sent by Admin / Office Depot back to the Customer with official quotation prices!
 */
export function generateAdminQuoteWhatsAppUrl(rfq: RFQRequest, settings: OwnerSettings): string {
  const p = rfq.pricing;
  const lines: string[] = [];

  lines.push(`🏢 *OFFICE DEPOT QUOTATION PROPOSAL*`);
  lines.push(`*REQUEST. QUOTE. DELIVER.*`);
  lines.push(`━━━━━━━━━━━━━━━━━━━━━━`);
  lines.push(`*Quotation Ref:* ${rfq.referenceNumber || rfq.id}`);
  lines.push(`*Date:* ${new Date().toLocaleDateString()}`);
  lines.push(`*Quoted To:* ${rfq.customer.name} ${rfq.customer.company ? '(' + rfq.customer.company + ')' : ''}`);
  lines.push(`*Delivery To:* ${rfq.customer.deliveryLocation}`);
  lines.push(``);
  lines.push(`📋 *PRICING BREAKDOWN:*`);

  rfq.items.forEach((item, idx) => {
    const unitPrice = item.quotedUnitPrice || 0;
    const total = item.quotedTotal || unitPrice * item.quantity;
    lines.push(
      `${idx + 1}. *${item.name}*` +
      `\n   ${item.quantity} ${item.unit} × රු. ${formatNumber(unitPrice)} = *රු. ${formatNumber(total)}*`
    );
  });

  lines.push(`━━━━━━━━━━━━━━━━━━━━━━`);
  if (p) {
    lines.push(`💰 *Subtotal:* රු. ${formatNumber(p.subtotal)}`);
    if (p.discountAmount > 0) {
      lines.push(`🏷️ *Discount (${p.discountPercent}%):* -රු. ${formatNumber(p.discountAmount)}`);
    }
    if (p.deliveryFee > 0) {
      lines.push(`🚚 *Delivery Fee:* +රු. ${formatNumber(p.deliveryFee)}`);
    }
    lines.push(`✅ *GRAND TOTAL: රු. ${formatNumber(p.grandTotal)}*`);
    lines.push(``);
    if (p.deliveryEstimate) lines.push(`⏱️ *Delivery Time:* ${p.deliveryEstimate}`);
    if (p.validDays) lines.push(`⏳ *Quotation Validity:* ${p.validDays} Days`);
    if (p.paymentTerms) lines.push(`💳 *Payment Terms:* ${p.paymentTerms}`);
    if (p.notes) lines.push(`📝 *Notes:* ${p.notes}`);
  } else if (rfq.ourQuotedTotal) {
    lines.push(`✅ *GRAND TOTAL: රු. ${formatNumber(rfq.ourQuotedTotal)}*`);
  }

  lines.push(``);
  lines.push(`📞 *Office Depot Hotline:* ${settings.whatsappNumber || '+94 77 123 4567'}`);
  lines.push(`📧 *Email:* ${settings.email}`);
  lines.push(`_To confirm this order, please reply directly to this message or send your Purchase Order (PO)._`);

  const encodedText = encodeURIComponent(lines.join('\n'));
  const cleanPhone = rfq.customer.phone.replace(/\D/g, '');
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}

/**
 * Mailto link sent by Admin to Customer
 */
export function generateAdminQuoteEmailUrl(rfq: RFQRequest, settings: OwnerSettings): string {
  const subject = encodeURIComponent(`Official Price Quotation [${rfq.referenceNumber || rfq.id}] - ${settings.businessName}`);
  const lines: string[] = [];

  lines.push(`Dear ${rfq.customer.name},`);
  lines.push(``);
  lines.push(`Thank you for requesting a quotation with ${settings.businessName}.`);
  lines.push(`Here is our official pricing breakdown for your reference [${rfq.referenceNumber || rfq.id}]:`);
  lines.push(``);

  rfq.items.forEach((item, idx) => {
    const unitPrice = item.quotedUnitPrice || 0;
    const total = item.quotedTotal || unitPrice * item.quantity;
    lines.push(`${idx + 1}. ${item.name} (${item.quantity} ${item.unit}) @ LKR ${formatNumber(unitPrice)} = LKR ${formatNumber(total)}`);
  });

  if (rfq.pricing) {
    lines.push(``);
    lines.push(`Subtotal: LKR ${formatNumber(rfq.pricing.subtotal)}`);
    if (rfq.pricing.discountAmount > 0) lines.push(`Discount (${rfq.pricing.discountPercent}%): -LKR ${formatNumber(rfq.pricing.discountAmount)}`);
    if (rfq.pricing.deliveryFee > 0) lines.push(`Delivery Fee: +LKR ${formatNumber(rfq.pricing.deliveryFee)}`);
    lines.push(`Grand Total: LKR ${formatNumber(rfq.pricing.grandTotal)}`);
    lines.push(`Delivery Estimate: ${rfq.pricing.deliveryEstimate}`);
    lines.push(`Payment Terms: ${rfq.pricing.paymentTerms}`);
  }

  lines.push(``);
  lines.push(`Please let us know if you wish to proceed.`);
  lines.push(``);
  lines.push(`Best regards,`);
  lines.push(`${settings.businessName}`);
  lines.push(`Hotline: ${settings.whatsappNumber}`);

  const body = encodeURIComponent(lines.join('\n'));
  return `mailto:${rfq.customer.email || ''}?subject=${subject}&body=${body}`;
}

/**
 * Mailto alert sent to Owner/Admin with copy of the new customer RFQ
 */
export function generateAdminRfqAlertEmailUrl(rfq: RFQRequest, settings: OwnerSettings): string {
  const targetEmail = settings.adminNotificationEmail || settings.email;
  const subject = encodeURIComponent(`[NEW RFQ ALERT] ${rfq.referenceNumber || rfq.id} from ${rfq.customer.name} - ${settings.businessName}`);
  const lines: string[] = [];

  lines.push(`🔔 NEW CUSTOMER QUOTATION REQUEST`);
  lines.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  lines.push(`Reference ID: ${rfq.referenceNumber || rfq.id}`);
  lines.push(`Date: ${new Date(rfq.createdAt).toLocaleString()}`);
  lines.push(`Customer: ${rfq.customer.name}`);
  if (rfq.customer.company) lines.push(`Company: ${rfq.customer.company}`);
  lines.push(`Phone (WhatsApp): ${rfq.customer.phone}`);
  if (rfq.customer.email) lines.push(`Email: ${rfq.customer.email}`);
  lines.push(`Delivery Location: ${rfq.customer.deliveryLocation}`);
  lines.push(`Urgency: ${rfq.customer.urgency.toUpperCase()}`);
  if (rfq.customer.requiredDate) lines.push(`Required Date: ${rfq.customer.requiredDate}`);
  lines.push(``);
  lines.push(`REQUESTED ITEMS (${rfq.items.length}):`);
  lines.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

  rfq.items.forEach((item, idx) => {
    let line = `${idx + 1}. ${item.name} - ${item.quantity} ${item.unit}`;
    if (item.specs) line += ` (Specs: ${item.specs})`;
    if (item.targetBudget) line += ` [Target Budget: LKR ${formatNumber(item.targetBudget)}]`;
    lines.push(line);
  });

  if (rfq.attachments && rfq.attachments.length > 0) {
    lines.push(``);
    lines.push(`ATTACHED FILES (${rfq.attachments.length}):`);
    rfq.attachments.forEach((att) => lines.push(`- ${att.name} (${formatFileSize(att.size)})`));
  }

  if (rfq.customer.notes) {
    lines.push(``);
    lines.push(`Customer Special Notes:`);
    lines.push(rfq.customer.notes);
  }

  lines.push(``);
  lines.push(`View & set pricing in Admin Dashboard:`);
  lines.push(`${typeof window !== 'undefined' ? window.location.origin : ''}`);

  const body = encodeURIComponent(lines.join('\n'));
  return `mailto:${targetEmail}?subject=${subject}&body=${body}`;
}
